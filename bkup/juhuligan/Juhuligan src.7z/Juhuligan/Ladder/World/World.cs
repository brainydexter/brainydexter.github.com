﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;
using Ladder.GameStates.GameMenu.PlayGameMenu;
#endregion

namespace Ladder.WorldNS
{
    class World : DrawableGameComponent,IWorld
    {
        #region Fields

        private int[,] mapArray;

        private Vector2 viewPort;

        private SpriteSheet tileSpriteSheet;

        private Texture2D background;

        public List<Vector2> checkPointsList;

        #endregion

        #region Properties

        public List<Vector2> CheckPointsList
        {
            get { return checkPointsList; }
        }

        #endregion

        #region Initialization

        public World(Game game, string sheetName, int tileWidth, int tileHeight, int tileXCount, int tileYCount)
            : base(game)
        {
            Game.Services.AddService(typeof(IWorld), this);

            viewPort = Vector2.Zero;

            tileSpriteSheet = new SpriteSheet(game.Content, sheetName, tileWidth, tileWidth, 3, 3, tileXCount, tileYCount);

            checkPointsList = new List<Vector2>();
            LoadCheckPoints();
        }

        public override void Initialize()
        {
            base.Initialize();

            mapArray = LevelLoader.GetInstance(Game).LoadMap();
        }

        public void LoadContent()
        {
            base.LoadContent();

            tileSpriteSheet.Load();

            background = Game.Content.Load<Texture2D>(Constants.World_BackgroundPath);
        }

        #endregion

        #region Draw

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);

            GamePlayState.SSpriteBatch.Draw(background, new Rectangle(0, 0, Constants.WindowWidth, Constants.WindowHeight), Color.White);

            Vector2 topLeftScreen = Vector2.Zero;
            Vector2 rightBottomScreen = new Vector2(Constants.WindowWidth, Constants.WindowHeight);

            Vector2 topLeftWorld = ScreenToWorld(topLeftScreen);
            Vector2 rightBottomWorld = ScreenToWorld(rightBottomScreen);

            for (int x = (int)topLeftWorld.X; x <= (int)rightBottomWorld.X; x++)
            {
                for (int y = (int)topLeftWorld.Y; y < (int)rightBottomWorld.Y; y++)
                {
                    DrawOnScreen(mapValueAt(x, y), new Vector2((float)x, (float)y));
                }
            }
        }

        private void DrawOnScreen(int tileNumber, Vector2 worldPos)
        {
            Vector2 screenPosn = WorldToScreen(worldPos);

            if (0 != tileNumber)
            {
                GamePlayState.SSpriteBatch.Draw(
                    tileSpriteSheet.SpriteSheeet,
                    screenPosn,
                    //null,
                    tileSpriteSheet.getTextureRectangle(tileNumber), //tileNumber),
                    Color.White);
            }

        }

        public void DrawOnScreen(int tileNumber, Vector2 worldPos, SpriteSheet spriteSheet)
        {
            Vector2 screenPosn = WorldToScreen(worldPos);
            Rectangle drawRect = spriteSheet.getTextureRectangle(tileNumber);
            drawRect.X += 1;
            drawRect.Width = 48;
            drawRect.Y += 1;
            drawRect.Height = 48;

            {
                GamePlayState.SSpriteBatch.Draw(
                    spriteSheet.SpriteSheeet,
                    screenPosn, drawRect,
                    //spriteSheet.getTextureRectangle(tileNumber),
                    Color.White);
                    //,0f,Vector2.Zero,SpriteEffects.None,0f);
            }

        }

        #endregion

        #region Helper Methods

        public bool withinViewPort(Vector2 positionGrid)
        {
            return
                (positionGrid.X >= viewPort.X && positionGrid.X < viewPort.X + Constants.viewPortWidth) ?
                true : false;
        }

        /// <summary>
        /// Converts a Screen vector to world position
        /// </summary>
        /// <param name="screenPosn">Screen Position in terms of pixels</param>
        /// <returns>Vector as world position</returns>
        public Vector2 ScreenToWorld(Vector2 screenPosn)
        {
            Vector2 worldPosn = Vector2.Zero;

            screenPosn.X /= Constants.TileWidth;
            worldPosn.X = viewPort.X + screenPosn.X;

            screenPosn.Y /= Constants.TileHeight;
            worldPosn.Y = viewPort.Y + screenPosn.Y;

            return worldPosn;
        }

        /// <summary>
        /// Converts a world vector to screen position
        /// </summary>
        /// <param name="worldPosn">World Position</param>
        /// <returns>Vector as screen position</returns>
        public Vector2 WorldToScreen(Vector2 worldPosn)
        {
            Vector2 screenPosn = Vector2.Zero;

            screenPosn.X = worldPosn.X - viewPort.X;
            screenPosn.X *= Constants.TileWidth;

            screenPosn.Y = worldPosn.Y - viewPort.Y;
            screenPosn.Y *= Constants.TileHeight;

            return screenPosn;
        }

        /// <summary>
        /// Returns true if the given tile is solid
        /// </summary>
        public bool SolidSquare(int x, int y)
        {
            return !LevelLoader.GetInstance(Game).WalkThruTiles.Contains(mapValueAt(x, y));
        }

        public int mapValueAt(int x, int y)
        {
            return (
                    (x >= 0 && x < Constants.mapWidth) &&
                    (y >= 0 && y < Constants.mapHeight)
                    ) ?
               mapArray[x, y] : 0;
        }

        public void setViewPos(Vector2 pos)
        {
            viewPort.X += (pos.X - viewPort.X) * 0.9f ;
            //viewPort.X = (pos.X) * 0.9f;
            //viewPort.X = pos.X ;

            if (viewPort.X < 0)
                viewPort.X = 0;
            else if (viewPort.X + Constants.viewPortWidth > Constants.mapWidth)
                viewPort.X = Constants.mapWidth - Constants.viewPortWidth;
        }

        /// <summary>
        /// Always add checkpoints in increasing order.
        /// The first and last checkpoint refers to the starting and ending points.
        /// </summary>
        private void LoadCheckPoints()
        {
            checkPointsList.Add(new Vector2(4, 11));
            checkPointsList.Add(new Vector2(30, 9));
            checkPointsList.Add(new Vector2(50, 12));
        }

        #endregion

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);

            LevelLoader.GetInstance(Game).Dispose();
        }
      
    }
}
