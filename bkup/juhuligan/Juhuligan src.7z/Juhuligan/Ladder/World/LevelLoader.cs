﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;
using Ladder.GameObjects;
using Ladder.NPC;
using Ladder.Resources;
using Microsoft.Xna.Framework;
using System.Collections;
#endregion

namespace Ladder.WorldNS
{
    class LevelLoader
    {
        #region Fields

        private Game game;
        private int[,] mapArray;

        private static LevelLoader instance;

        #endregion

        #region Properties

        public List<int> WalkThruTiles;
        public Queue<QueItem> ResourceQ;
        public Queue<QueItem> EnemyQ;

        #endregion

        #region Initialization

        public static LevelLoader GetInstance(Game game)
        {
            if (instance == null)
                instance = new LevelLoader(game);

            return instance;
        }

        private LevelLoader(Game game)
        {
            this.game = game;

            WalkThruTiles = new List<int>();
            WalkThruTiles.Add(0);

            ResourceQ = new Queue<QueItem>();
            EnemyQ = new Queue<QueItem>();
        }

        public int[,] LoadMap()
        {
            

            int[,] tempArray = new int[Constants.mapHeight, Constants.mapWidth]
            {
#region data
              { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0 },
{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0 },
{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0 },
{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 14, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0 },
{ 0, 0, 0, 0, 18, 0, 0, 0, 18, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0 },
{ 0, 0, 0, 0, 18, 18, 0, 18, 18, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0 },
{ 0, 0, 0, 0, 18, 18, 0, 18, 18, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0 },
{ 0, 0, 0, 0, 18, 18, 18, 18, 18, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0 },
{ 0, 0, 0, 0, 4, 5, 5, 5, 4, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 40, 0, 0, 0, 0, 0, 40, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 24, 25, 26, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0 },
{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 40, 0, 0, 100, 0, 0, 40, 0, 0, 0, 9, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 41, 42, 43, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 3, 3, 3 },
{ 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 5, 4, 0, 123, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 33, 59, 17, 
0, 0, 0, 0, 100, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 
3, 123, 123, 123 },
{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 123, 0, 
0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 25, 12, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 5, 4, 0, 0, 
0, 0, 0, 0, 18, 0, 18, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 59, 0, 
0, 0, 0, 100, 100, 100, 0, 0, 0, 0, 0, 0, 0, 3, 3, 123, 
123, 123, 123, 123 },
{ 142, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 123, 0, 
41, 42, 43, 0, 0, 4, 5, 5, 5, 4, 0, 0, 41, 42, 43, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 123, 123, 123, 0, 40, 
0, 0, 0, 18, 0, 0, 0, 18, 0, 0, 0, 0, 40, 0, 0, 12, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 13, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 123, 123, 123, 
123, 123, 123, 123 },
{ 123, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 4, 123, 77, 
100, 59, 77, 18, 18, 18, 18, 39, 18, 18, 18, 18, 77, 59, 77, 142, 
18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 78, 123, 123, 123, 0, 0, 
0, 0, 18, 120, 0, 0, 0, 142, 18, 0, 0, 0, 0, 4, 77, 32, 
77, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 120, 123, 123, 123, 123, 123, 
123, 123, 123, 123 },
{ 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 4, 
5, 5, 4, 123, 0, 39, 0, 123, 4, 5, 5, 5, 4, 123, 123, 123, 
123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123 },
{ 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 123, 
123, 123, 123, 123 }
#endregion

            };

            mapArray = new int[Constants.mapWidth, Constants.mapHeight];

            for (int x = 0; x < Constants.mapWidth; x++)
            {
                for (int y = 0; y < Constants.mapHeight; y++)
                {
                    mapArray[x, y] = Transform(tempArray[y, x],x,y);
                }
            }

            return mapArray;
        
        }

        private int Transform(int val,int x,int y)
        {
            switch (val)
            {
                case 3: return 2;
                case 4: return 3;
                case 5: return 4;
                case 123: return 183;
                case 77:
                    WalkThruTiles.Add(80);
                    return 80;
                //case 100: return 104;
                case 59: return 61;
                case 41:
                    WalkThruTiles.Add(42);
                    return 42;
                case 42: return 43;
                case 43:
                    WalkThruTiles.Add(44);                    
                    return 44;
                default: Populate(val,x,y); return 0;
            }
        }

        private void Populate(int val, int x, int y)
        {
            switch (val)
            {
                case 18:
                    ResourceQ.Enqueue(new QueItem((int)PickupType.Coin, x, y));
                    break;

                case 40:
                    ResourceQ.Enqueue(new QueItem((int)PickupType.Ammo, x, y));
                    break;

                case 78:
                    ResourceQ.Enqueue(new QueItem((int)PickupType.Shield, x, y));
                    break;

                case 100:
                    ResourceQ.Enqueue(new QueItem((int)PickupType.MediPack, x, y));
                    break;

                case Constants.WeaponTile:
                    ResourceQ.Enqueue(new QueItem(Constants.WeaponTile, x, y));
                    break;

                case 120:
                    EnemyQ.Enqueue(new QueItem((int)EnemyType.Turret, x, y, Direction.Left));
                    break;

                case 142:
                    EnemyQ.Enqueue(new QueItem((int)EnemyType.Turret, x, y, Direction.Right));
                    break;

                case 9:
                    EnemyQ.Enqueue(new QueItem((int)EnemyType.MadAx, x, y, Direction.Left));
                    break;

                case 10:
                    EnemyQ.Enqueue(new QueItem((int)EnemyType.MoFoBoom, x, y, Direction.Left));
                    break;

                case 12:
                    EnemyQ.Enqueue(new QueItem((int)EnemyType.Frogger, x, y, Direction.Right));
                    break;

                case 13:
                    EnemyQ.Enqueue(new QueItem((int)EnemyType.Frogger, x, y, Direction.Left));
                    break;

                case 14:
                    EnemyQ.Enqueue(new QueItem((int)EnemyType.Ceiler, x, y, Direction.None));
                    break;
            }
        }
        #endregion

        public void Dispose()
        {
            mapArray = null;

            WalkThruTiles.Clear();
            ResourceQ.Clear();
            EnemyQ.Clear();

            WalkThruTiles = null;
            ResourceQ = null;
            EnemyQ = null;

            instance = null;
        }
    }

    
}
