﻿using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Library.SpriteSheetNS;

namespace Ladder.WorldNS
{
    interface IWorld
    {

        List<Vector2> CheckPointsList { get; }

        int mapValueAt(int x, int y);

        /// <summary>
        /// Checks to see if a given Point specified in the world coordinates 
        /// is within the current viewport or not.
        /// </summary>
        /// <param name="worldPosition">Point representing a cell in the world mapArray.</param>
        /// <returns>True, if the specified worldPosition is within the current viewPort</returns>
        bool withinViewPort(Vector2 worldPosition);

        void setViewPos(Vector2 pos);

        /// <summary>
        /// Converts a world vector to screen position
        /// </summary>
        /// <param name="worldPosn">World Position</param>
        /// <returns>Vector as screen position</returns>
        Vector2 WorldToScreen(Vector2 worldPosn);

        /// <summary>
        /// Converts a Screen vector to world position
        /// </summary>
        /// <param name="screenPosn">Screen Position in terms of pixels</param>
        /// <returns>Vector as world position</returns>
        Vector2 ScreenToWorld(Vector2 screenPosn);

        bool SolidSquare(int x, int y);

        /// <summary>
        /// Draws the sprite indexed at tileNumber within the spriteSheet at the specified worldPosition
        /// </summary>
        /// <param name="tileNumber"></param>
        /// <param name="worldPos"></param>
        /// <param name="spriteSheet"></param>
        void DrawOnScreen(int tileNumber, Vector2 worldPos, SpriteSheet spriteSheet);
    }
}
