﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
#endregion

namespace Ladder
{
    class ClassTemplate
    {
        #region Fields


        #endregion

        #region Properties


        #endregion

        #region Initialization


        #endregion

        #region Update


        #endregion

        #region Draw


        #endregion

        #region Helper Methods


        #endregion
    }
}
