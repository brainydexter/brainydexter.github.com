﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;
using Library.UtilsNS;
using Ladder.GameStates.GameMenu.PlayGameMenu;

namespace Ladder.UI
{
    /// <summary>
    /// To use:
    /// 1. Call constructor.
    /// 2. Call LoadContent.
    /// 3. Call Update
    /// 4. Call Draw
    /// </summary>
    class Face
    {
        #region Fields

        float health; //uses health as percentage. i.e. health of 120 = 80% {from 120/150}

        List<Vector2> leftEyeBrow;
        List<Vector2> rightEyeBrow;

        List<Vector2> faceRectList;

        List<Vector2> smilePointsList;
        List<Vector2> leftSmileLineList;
        List<Vector2> rightSmileLineList;

        Texture2D pencil;
        ContentManager Content;
        Rectangle faceArea;

        #endregion

        #region Properties

        public float Health
        {
            get { return health; }
            set
            {
                health = (value * 1.0f) / Constants.Player_Max_Health;
            }
        }

        #endregion

        #region Initialization

        public Face(int hp, Rectangle faceRect, ContentManager Content)
        {
            Health = hp;

            leftEyeBrow = new List<Vector2>();
            rightEyeBrow = new List<Vector2>();

            faceRectList = new List<Vector2>();

            smilePointsList = new List<Vector2>();
            leftSmileLineList = new List<Vector2>();
            rightSmileLineList = new List<Vector2>();

            this.Content = Content;
            faceArea = faceRect;

            //
            for (int i = faceArea.Left; i < faceArea.Right; i++)
            {
                faceRectList.Add(new Vector2(i, faceArea.Top));
                faceRectList.Add(new Vector2(i, faceArea.Bottom));
            }
            for (int i = faceArea.Top; i < faceArea.Bottom; i++)
            {
                faceRectList.Add(new Vector2(faceArea.Left, i));
                faceRectList.Add(new Vector2(faceArea.Right,i));
            }
            //
        }

        public void LoadContent()
        {
            pencil = Content.Load<Texture2D>(Constants.PencilTexture);
        }

        #endregion

        #region Update
        
        public void Update(GameTime gameTime, int hp)
        {
            Health = hp;

            UpdateLeftEyeBrow();
            UpdateRightEyeBrow();

            UpdateSmile();
        }

        private void UpdateRightEyeBrow()
        {
            int ht = faceArea.Height / 4;
            float smileHeight = (Health * ht);

            Vector2 leftPoint = new Vector2(faceArea.Right - (faceArea.Width / 4), faceArea.Top + smileHeight);
            Vector2 rightPoint = new Vector2(faceArea.Right , faceArea.Top + ht - smileHeight);
            Vector2 heightPoint = new Vector2(leftPoint.X + 20, leftPoint.Y - 30);

            rightEyeBrow = Interpolation.Quadratic(leftPoint, heightPoint, rightPoint);
            //Interpolation.Linear(leftPoint, rightPoint);
        }

        private void UpdateLeftEyeBrow()
        {
            int ht = faceArea.Height / 4;
            float smileHeight = (Health * ht);

            Vector2 leftPoint = new Vector2(faceArea.Left + 4 , 5 + faceArea.Top + ht - smileHeight);            
            Vector2 rightPoint = new Vector2(faceArea.Left + (faceArea.Width/4) , faceArea.Top + smileHeight);
            Vector2 heightPoint = new Vector2(rightPoint.X - 20, rightPoint.Y - 30);

            //leftEyeBrow = Interpolation.Linear(leftPoint,rightPoint);
            leftEyeBrow = Interpolation.Quadratic(leftPoint, heightPoint, rightPoint);
        }

        private void UpdateSmile()
        {
            float smileHeight = faceArea.Center.Y + (Health * (faceArea.Height/2));

            Vector2 leftPoint = new Vector2(faceArea.Left + (faceArea.Width / 4), faceArea.Center.Y + faceArea.Height / 4);
            Vector2 heightPoint = new Vector2(faceArea.Center.X, smileHeight);
            Vector2 rightPoint = new Vector2(faceArea.Right - (faceArea.Width / 4), faceArea.Center.Y + faceArea.Height / 4);
            
            smilePointsList = Interpolation.Quadratic(leftPoint,heightPoint,rightPoint);
            leftSmileLineList = Interpolation.TangentLine(leftPoint, heightPoint, leftPoint);
            rightSmileLineList = Interpolation.TangentLine(heightPoint, rightPoint, rightPoint);
        }

        #endregion

        #region Draw

        public void Draw(GameTime gameTime)
        {
            DrawEyeBrows(gameTime);
            DrawSmile(gameTime);

            GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont,
                //(Health * Constants.Player_Max_Health).ToString(), 
                (int)(Health * 100) + "%", 
                new Vector2(faceArea.Center.X - 20, faceArea.Center.Y),
                Color.Green);

            DrawList(faceRectList);
        }

        private void DrawEyeBrows(GameTime gameTime)
        {
            DrawList(leftEyeBrow);
            DrawList(rightEyeBrow);
        }

        private void DrawSmile(GameTime gameTime)
        {
            DrawList(smilePointsList);
            DrawList(leftSmileLineList);
            DrawList(rightSmileLineList);
        }

        private void DrawList(List<Vector2> pointsList)
        {
            foreach (Vector2 posn in pointsList)
                GamePlayState.SSpriteBatch.Draw(pencil, posn, Color.White);
        }

        #endregion
               
    }
}
