using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

using Ladder.PC;
using Library.SpriteSheetNS;
using Ladder.GameStates.GameMenu.PlayGameMenu;

namespace Ladder.UI
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class Hud : DrawableGameComponent
    {
        IPlayer player;

        Face face;
        Rectangle faceRectangle;

        SpriteSheet spriteSheet;

        public Hud(Game game)
            : base(game)
        {
            Game.Services.AddService(typeof(Hud), this);
            //Game.Components.Add(this);
            
            // TODO: Construct any child components here 
            
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            player = Game.Services.GetService(typeof(IPlayer)) as IPlayer;

            // TODO: Add your initialization code here
            faceRectangle = new Rectangle(
                                (Game.GraphicsDevice.Viewport.Width / 2),
                                0,
                                200, 200);

            face = new Face(player.Health, faceRectangle, Game.Content);
            spriteSheet = new SpriteSheet(Game.Content, Constants.HUDSpriteSheet, 48, 48, 10, 10);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            face.LoadContent();
            spriteSheet.Load();
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            face.Update(gameTime, player.Health);

            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            GamePlayState.SSpriteBatch.Begin();
            
            //Draw face
            GamePlayState.SSpriteBatch.Draw(spriteSheet.SpriteSheeet,
                new Vector2(faceRectangle.Left + 2, faceRectangle.Top + 15),// + faceRectangle.Height / 8),
                spriteSheet.getTextureRectangle(2),
                Color.White);
            GamePlayState.SSpriteBatch.Draw(spriteSheet.SpriteSheeet,
                new Vector2(faceRectangle.Right - 70, faceRectangle.Top + faceRectangle.Height / 8),
                spriteSheet.getTextureRectangle(3),
                Color.White);
            //GamePlayState.SSpriteBatch.Draw(spriteSheet.SpriteSheeet,
            //    new Vector2(faceRectangle.Left + faceRectangle.Width/4, faceRectangle.Top ),
            //    spriteSheet.getTextureRectangle(4),
            //    Color.White);

            face.Draw(gameTime);

            //Draw Lives
            GamePlayState.SSpriteBatch.Draw(spriteSheet.SpriteSheeet,
                new Vector2(faceRectangle.Right + 100.0f, faceRectangle.Height / 2),
                spriteSheet.getTextureRectangle(0),
                Color.White);

            GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, player.Lives.ToString(), 
                new Vector2(faceRectangle.Right + 175.0f, faceRectangle.Height/2),
                Color.Red);

            //Draw coins
            GamePlayState.SSpriteBatch.Draw(spriteSheet.SpriteSheeet,
                new Vector2(faceRectangle.Right + 200.0f, faceRectangle.Height / 2),
                spriteSheet.getTextureRectangle(1),
                Color.White);
            GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, player.Coins.ToString(),
                new Vector2(faceRectangle.Right + 250.0f, faceRectangle.Height / 2),
                Color.DarkGreen);

            //Draw ammo
            GamePlayState.SSpriteBatch.Draw(spriteSheet.SpriteSheeet,
                new Vector2(faceRectangle.Left - 300.0f, faceRectangle.Height / 2),
                spriteSheet.getTextureRectangle(1),
                Color.White);
            GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, player.Ammo.ToString(),
                new Vector2(faceRectangle.Left - 200.0f, faceRectangle.Height / 2),
                Color.Brown);

            GamePlayState.SSpriteBatch.End();

            //base.Draw(gameTime);
        }
    }
}