﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

using Ladder.NPC;
using Library.InputNS;
using Ladder.WorldNS;
using Ladder.Resources;
using Ladder.GameObjects;

using Library.SpriteSheetNS;
using Ladder.GameStates.GameMenu.PlayGameMenu;
using Library.AudioNS;

#endregion

namespace Ladder.PC
{
    class Player : GameObject,IPlayer
    {
        #region Fields

        int health;
        int lives;  //at any time, represents the number of lives; the player has.

        IMouseHandler input;

        Weapon gun;

        bool shield;

        BotPlayer bot;

        VictoryState victory;

        int coinCount = 0;

        #endregion

        #region Properties

        public Vector2 WorldPosition
        {
            get { return worldPosition; }
        }

        public int Health
        {
            get { return health; }
        }

        public int Lives
        {
            get { return lives; }
        }

        public int Coins
        {
            get { return coinCount; }
        }

        public int Ammo
        {
            get { return gun != null ? gun.BulletList.Count : 0; } 
        }

        /// <summary>
        /// Denotes if the player has shield or not
        /// </summary>
        public bool Shield
        {
            get { return shield; }
            set { shield = value; }
        }

        public SpriteSheet Player_SpriteSheet
        {
            get { return spriteSheet; }
        }

        public BotPlayer EnemyPlayer
        {
            get { return bot; }
        }

        public VictoryState Victory
        {
            get { return victory; }
            set { victory = value; }
        }
        #endregion

        #region Initialization

        public Player(Game game)
            : base(game, Constants.Player_SpriteSheet_Path,
                    Constants.Player_TileWidth, Constants.Player_TileHeight,
                    Constants.Player_TileXCount, Constants.Player_TileYCount
                   )
        {
            Game.Services.AddService(typeof(IPlayer), this);

            lives = Constants.Player_Lives;
        }

        public override void Initialize()
        {
            base.Initialize();

            InitializeServices();
           
            health = Constants.Player_Max_Health;

            worldPosition = CheckPointFromPosition();

            Shield = false;

            gun = null; //whenever player starts, he does not have a gun

            victory = VictoryState.Playing;

        }

        /// <summary>
        /// Returns the checkPoint
        /// </summary>
        /// <returns></returns>
        private Vector2 CheckPointFromPosition()
        {
            Vector2 checkPoint = Vector2.Zero;
            for(int i = 0; i < world.CheckPointsList.Count; i++)
            {
                if (worldPosition.X < world.CheckPointsList[i].X)
                {
                    if (0 == i)
                    {
                        checkPoint = world.CheckPointsList[0];
                        break;
                    }
                    checkPoint = world.CheckPointsList[i - 1];
                    break;
                }

            }

            return checkPoint;
        }

       #endregion

        #region Update

        public override void Update(GameTime gameTime)
        {
            Direction hitDirection = Direction.None;

            hitDirection = UpdateMovement(gameTime);

            UpdateInput(gameTime, hitDirection);

            UpdateState(gameTime);

            UpdateWeapon(gameTime);

            UpdateViewPort(gameTime);
        }

        #region Update Helpers

        /// <summary>
        /// Moves the object based on the velocity. Also, sets the velocity to 0 if it has been obstructed.
        /// </summary>
        /// <param name="gameTime"></param>
        private Direction UpdateMovement(GameTime gameTime)
        {
            Direction hitDirection = base.Move();

            if (((hitDirection & Direction.Left) != 0) || ((hitDirection & Direction.Right) != 0))
            {
                velocity.X = 0;
            }

            if (((hitDirection & Direction.Up) != 0) || ((hitDirection & Direction.Down) != 0))
            {
                velocity.Y = 0;
            }

            return hitDirection;
        }

        private void UpdateInput(GameTime gameTime, Direction hitDirection)
        {
            if (input.KeyHeldDown(Keys.Right))
            {
                velocity.X += Constants.PlayerAcceleration + Constants.PlayerDeceleration;

                if (velocity.X > Constants.PlayerMaxSpeed)
                    velocity.X = Constants.PlayerMaxSpeed;
            }
            else if (input.KeyHeldDown(Keys.Left))
            {
                velocity.X -= Constants.PlayerAcceleration + Constants.PlayerDeceleration;

                if (velocity.X < -Constants.PlayerMaxSpeed)
                    velocity.X = (-Constants.PlayerMaxSpeed);
            }
            if (input.KeyJustPressed(Keys.Up))
            {
                if ((hitDirection & Direction.Down) != 0)
                {
                    velocity.Y = -Constants.PlayerJumpSpeed;
                    SoundDJ.GetInstance().PlayCue("jump 2");
                }
            }
        }

        private void UpdateState(GameTime gameTime)
        {
            velocity.X = Constants.TendToZero(velocity.X, Constants.PlayerDeceleration);

            velocity.Y += Constants.PlayerGravity;
        }

        private void UpdateViewPort(GameTime gameTime)
        {
            world.setViewPos(new Vector2(worldPosition.X - (Constants.viewPortWidth / 2), 0));
        }

        private void UpdateWeapon(GameTime gameTime)
        {
            if (gun != null)
            {
                gun.Update(gameTime, worldPosition);
                CheckForHit(gun.BulletList);
            }
        }

        public void UpdateAmmo(int count)
        {
            if(gun!= null)
                gun.addAmmo(count);
        }

        public void UpdateCoin(int amount)
        {
            coinCount += amount;

            if (coinCount >= 100)
            {
                lives++;
                coinCount -= 100;
            }
        }

        /// <summary>
        /// Accounts for damage done to enemies by bullet shots
        /// </summary>
        /// <param name="bulletList">Bullets within the gun</param>
        private void CheckForHit(List<Bullet> bulletList)
        {
            List<EnemyDmg> updateEnemy = new List<EnemyDmg>();

            foreach (Enemy enemy in bot.Enemies)
            {
                foreach (Bullet bullet in bulletList)
                {
                    if (bullet.BoundingBox.Intersects(enemy.BoundingBox))
                    {
                        updateEnemy.Add(new EnemyDmg(enemy, bullet.Damage));
                        bullet.Active = false;
                    }
                }
            }

            foreach (EnemyDmg enemyDmg in updateEnemy)
            {
                enemyDmg.enemy.updateHealth(enemyDmg.Damage);
            }

        }

        #endregion
        
        #endregion

        #region Draw

        public override void Draw(GameTime gameTime)
        {
            //Drawing the player
            world.DrawOnScreen(tileNumber, worldPosition, spriteSheet);

            //draw gun
            if(gun!= null)
                gun.Draw(gameTime);

            
        }

        private void DrawDebugInfo()
        {
            if (true)
            {
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Coins: " + coinCount.ToString(), new Vector2(800, 50), Color.Black);
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Lives: " + lives.ToString(), new Vector2(800, 150), Color.Black);

                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Position X: " + worldPosition.X.ToString(), new Vector2(500, 50), Color.Black);
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Y: " + worldPosition.Y.ToString(), new Vector2(650, 50), Color.Black);
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Screen X: " + ScreenX.ToString(), new Vector2(600, 100), Color.Black);
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Screen Y: " + ScreenY.ToString(), new Vector2(750, 100), Color.Black);
                
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Origin X: " + OriginX.ToString(), new Vector2(600, 120), Color.Black);
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Origin Y: " + OriginY.ToString(), new Vector2(750, 120), Color.Black);
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Origin X: " + (int)OriginX/Constants.TileWidth, new Vector2(600, 140), Color.Black);
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Origin Y: " + (int)OriginY / Constants.TileHeight, new Vector2(750, 140), Color.Black);

                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Grid X: " + GridX.ToString(), new Vector2(600, 160), Color.Black);
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Grid Y: " + GridY.ToString(), new Vector2(750, 160), Color.Black);

                GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Shield: " + Shield, new Vector2(600, 100), Color.Black);
                GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, "Health: " + health.ToString(), new Vector2(600, 180), Color.Black);
                //GamePlayState.SSpriteBatch.DrawString(GamePlayState.SSpriteFont, 
                //    world.mapValueAt(ScreenX, (int)(position.Y / Constants.TileHeight)).ToString(), 
                //    new Vector2(position.X + 20, position.Y + 16),
                //    Color.Black);
            }
        }

        #endregion

        #region Helper Methods

        private void InitializeServices()
        {
            input = Game.Services.GetService(typeof(IMouseHandler)) as IMouseHandler;
            bot = Game.Services.GetService(typeof(BotPlayer)) as BotPlayer;
        }

        public void pickUp(Weapon weapon)
        {
            SoundDJ.GetInstance().PlayCue("weapon");
            if (gun == null)
                gun = weapon;
            else
                gun.addAmmo(weapon.BulletList.Count);
        }

        /// <summary>
        /// updates player state to dead if health is less than or equal to 0 after damage
        /// Also, updates lives. If he runs out of lives, player is declared dead. Else, he is re-initialized 
        /// and the number of available lives are decreased
        /// </summary>
        /// <param name="damage">Amount of damage</param>
        public void UpdateHealth(int damage)
        {
            health -= damage;

            if (health > Constants.Player_Max_Health)
                health = Constants.Player_Max_Health;

            if (health <= 0)
            {
                if (lives == 1)
                {
                    SoundDJ.GetInstance().PlayCue("lost");
                    victory = VictoryState.Defeated;
                }
                else
                {
                    SoundDJ.GetInstance().PlayCue("dies");
                    lives--;
                    Initialize();
                }
            }
        }

        #endregion

    }

    struct EnemyDmg
    {
        public Enemy enemy;
        public int Damage;

        public EnemyDmg(Enemy en, int dmg)
        {
            enemy = en;
            Damage = dmg;
        }
    };
}
