#region Using statements

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;

using Ladder.Resources;
using Ladder.NPC;
using Library.SpriteSheetNS;

#endregion

namespace Ladder.PC
{
    interface IPlayer
    {
        Vector2 WorldPosition { get;}
        Rectangle BoundingBox { get; }

        int Health { get; }
        int Lives { get; }
        int Coins { get; }
        bool Shield { get; set; }
        int Ammo { get; }

        SpriteSheet Player_SpriteSheet { get; }
        BotPlayer EnemyPlayer { get; }
        VictoryState Victory { get; set; }

        void UpdateHealth(int damage);
        void UpdateAmmo(int count);

        void pickUp(Weapon weapon);

        void UpdateCoin(int p);
    }
}
