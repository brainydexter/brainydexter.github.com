﻿using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Ladder
{
   
    class Constants
    {
        #region Window related data
        
        public const int WindowWidth = 1024;
        public const int WindowHeight = 768;
        public static bool Debug = !true;

        public const string Game_LogoPath = "Art Assets/World Textures/Logo";

#endregion

        #region Font related data

        public const string FontPath = "Fonts/Font";

#endregion

        #region World related data

        public const int mapWidth = 100;
        public const int mapHeight = 16;
        public const int viewPortWidth = 21;
        public const int viewPortHeight = 16;
        public const string World_BackgroundPath = "Art Assets/World Textures/Background";
               

        #region Spritesheet related data

        public static string LevelPath = "Art Assets/World Textures/worldTileSheet";
        public const int TileWidth = 48;
        public const int TileHeight = 48;
        public const int TileXCount = 18;
        public const int TileYCount = 11;

        #endregion

        #endregion

        #region Player related data

        public const int Player_Max_Health = 500;
        public const int Player_Lives = 3;

        public const float Player_Speed = 4.0f;
        public const string Player_Sprite_Path = "Art Assets/Player Textures/Player_Sprite";
        public const int Player_Bullet_Tile = 2;

        #region SpriteSheet data
        public const string Player_SpriteSheet_Path = "Art Assets/Player Textures/Player_SpriteSheet";
        public const int Player_TileWidth = 48;
        public const int Player_TileHeight = 48;
        public const int Player_TileXCount = 10;
        public const int Player_TileYCount = 10;

        #endregion

        #region Movement data

        public const float PlayerAcceleration = 0.08f;
        public const float PlayerDeceleration = 0.02f;
        public const float PlayerMaxSpeed = 0.2f;
        public const float PlayerJumpSpeed = 0.30f;
        public const float PlayerGravity = 0.01f;

        #endregion

        #endregion

        #region BotPlayer related data

        #region SpriteSheet data
        public const string BotPlayer_SpriteSheet_Path= "Art Assets/BotPlayer Textures/Enemy_SpriteSheet";
        public const int BotPlayer_TileWidth = 48;
        public const int BotPlayer_TileHeight = 48;
        public const int BotPlayer_TileXCount = 6;
        public const int BotPlayer_TileYCount = 9;
        #endregion

        #endregion

        #region Turret related data

        public const int Turret_Health = 50;
        public const float Turret_ReloadTime = 240.0f;

        //pixel data
        public const int Turret_Body_Damage = 5;
        public const int Turret_Bullet_Tile = 49;

        #endregion

        #region Frogger related data

        public const int Frogger_Health = 100;
        public const float Frogger_ReloadTime = 1000f;

        //pixel data
        public const int Frogger_Body_Damage = 5;
        public const int Frogger_Body_Tile = 4;
        public const int Frogger_Bullet_Tile = 48;

        #endregion

        #region Lumber related data

        public const int Lumber_Damage = 20;

        public const int Lumber_Health = 100;

        #endregion

        #region Ceiler related data

        public const int Ceiler_Damage = 15;
        public const int Ceiler_Health = 80;

        public const int Ceiler_Bullet_Tile = 49;

        #endregion

        #region MadAx related data

        public const int MadAx_Health = 50;
        public const float MadAx_ReloadTime = 500.0f;

        public const int MadAx_BodyDamage = 5;
        public const int MadAx_Bullet_Tile = 50;

        #endregion

        #region MoFoBoom related data

        public const int MoFoBoom_Health = 50;
        public const float MoFoBoom_ReloadTime = 1500.0f;

        //pixel data
        public const int MoFoBoom_BodyDamage = 5;
        public const int MoFoBoom_Bullet_Tile = 50;

        #endregion

        #region Resources related data

        #region Spritesheet related data
        public const string Resources_Sprite_Path = "Art Assets/Resources Textures/PickUp_Spritesheet";
        public const int ResourceSprite_TileWidth = 48;
        public const int ResourceSprite_TileHeight = 48;
        public const int ResourceSprite_TileXCount = 7;
        public const int ResourceSprite_TileYCount = 1;
        #endregion

        public const int HealthPack = -25;
        public const int AmmoPack = 3;
        #endregion

        #region Weapon related data
        public const int WeaponTile = 39;
        
        #endregion

        #region UI related data

        public const string HUDSpriteSheet = "Art Assets/UI/hudSpriteSheet";
        public const string PencilTexture = "Art Assets/UI/blackdot";

        #endregion

        #region Static methods

        public static bool IsInt(float value)
        {
            return ((float)((int)value) == value);
        }

        public static float TendToZero(float val, float amount)
        {
            if (val > 0f && (val -= amount) < 0f) return 0f;
            if (val < 0f && (val += amount) > 0f) return 0f;
            return val;
        }

        public static bool VectorWithin(Vector2 givenPos, Vector2 startPos, Vector2 size)
        {
            return
                (
                    givenPos.X >= startPos.X && givenPos.X < (startPos.X + size.X) &&
                    givenPos.Y >= startPos.Y && givenPos.Y < (startPos.Y + size.Y)
                ) 
                    ?
                true : false;
        }

        #endregion
    }

    struct QueItem
    {
        public int type, x, y;
        public Direction direction;

        public QueItem(int type, int x, int y)
        {
            this.type = type;
            this.x = x;
            this.y = y;
            this.direction = Direction.None;
        }

        public QueItem(int type, int x, int y, Direction direction)
            :this(type,x,y)
        {
            this.direction = direction;
        }
    }

    public enum Direction
    {
        None = 0x0000,
        Up = 0x0001,
        Right = 0x0002,
        Down = 0x0004,
        Left = 0x0008
    }

    public enum UpdateAction
    {
        None,
        Remove
    }

    enum PickupType
    {
        None = 0x0000,
        MediPack = 0x0001,
        Shield = 0x0002,
        Ammo = 0x0004,
        Coin = 0x008,
        Home = 0x016
    }

}
