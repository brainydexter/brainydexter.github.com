﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;

using Ladder.GameObjects;
using Ladder.PC;

#endregion

namespace Ladder.NPC
{
    class Ceiler : Turret
    {
        public Ceiler(Game game, BotPlayer boss, Vector2 posn, Direction facingDirn)
            : base(game, boss, posn, facingDirn)
        {
            tileNumber = 6;
        }

        public override void Initialize()
        {
            base.Initialize();

            for (int i = 0; i < 10; i++)
                bulletList.Add(new Bullet(Game, spriteSheet, Constants.Ceiler_Bullet_Tile));

            reloadingTime = 100.0f;

            player = master.Player;
        }

        public override void Update(GameTime gameTime)
        {
            if (Active)
                Shoot(gameTime);

            foreach (Bullet bullet in bulletList)
                bullet.Update(gameTime);
        }

        protected override void Shoot(GameTime gameTime)
        {
            Bullet bullet = LoadBullet(gameTime);
            if (bullet != null)
                bullet.Fire(worldPosition, new Vector2(player.WorldPosition.X, player.WorldPosition.Y), TrajectoryType.Straight);
        }

        protected Bullet LoadBullet(GameTime gameTime)
        {
            reloadingTime += (float)gameTime.ElapsedGameTime.Milliseconds;

            if (reloadingTime > 300f)
            {
                reloadingTime = 0.0f;

                foreach (Bullet bullet in bulletList)
                    if (!bullet.Active)
                    {
                        bullet.Active = true;
                        drawFunc = Draw;
                        return bullet;
                    }
            }
            return null;
        }

        public override void Draw(GameTime gameTime)
        {
            string animString = "Ceiler";

            if (player.WorldPosition.X - worldPosition.X > 0)
                animString += "E";
            else 
                animString += "W";

            bool completed = false;

            world.DrawOnScreen(SpriteAnimation.GetInstance().PlayAnimation(animString, out completed), worldPosition, spriteSheet);

            if (completed)
                drawFunc = base.DrawEnemy;
        }
    }
}
