#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;

using Ladder.PC;
using Ladder.WorldNS;
using Ladder.GameObjects;
using Library.AudioNS;
#endregion

namespace Ladder.NPC
{
    /// <summary>
    /// Resposible for:
    /// - Loading & Initialising Enemies
    /// - Spawn/destroy Enemies based of player's position
    /// - draw Enemies
    /// </summary>
    class BotPlayer : DrawableGameComponent
    {
        #region Fields

        List<Enemy> enemyList;

        SpriteSheet enemySpriteSheet;

        IPlayer player;
        IWorld world;

        #endregion

        #region Properties

        public List<Enemy> Enemies
        {
            get { return enemyList; }
        }

        public IWorld World
        {
            get { return world; }
        }

        public IPlayer Player
        {
            get { return player; }
        }

        public SpriteSheet SpriiteSheet
        {
            get { return enemySpriteSheet; }
        }
        #endregion

        #region Initialization

        /// <summary>
        /// Makes a common spritesheet.
        /// 
        /// </summary>
        /// <param name="game"></param>
        public BotPlayer(Game game)
            : base(game)
        {
            Game.Services.AddService(typeof(BotPlayer), this);

            enemySpriteSheet = new SpriteSheet(game.Content, Constants.BotPlayer_SpriteSheet_Path,
                                    Constants.BotPlayer_TileWidth, Constants.BotPlayer_TileHeight,
                                    Constants.BotPlayer_TileXCount, Constants.BotPlayer_TileYCount);

            enemyList = new List<Enemy>();
        }

        /// <summary>
        /// Makes new enemies.
        /// Initializes all the enemies by also calling their Initialize() method
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();

            world = Game.Services.GetService(typeof(IWorld)) as IWorld;
            player = Game.Services.GetService(typeof(IPlayer)) as IPlayer;

            foreach (QueItem item in LevelLoader.GetInstance(Game).EnemyQ)
            {
                addEnemy(item.x, item.y, (EnemyType)item.type, item.direction);
            }

            //addEnemy(0, 11, EnemyType.Turret, Direction.Right);
            //addEnemy(8, 13, EnemyType.Turret, Direction.Left);
            //addEnemy(9, 13, EnemyType.Turret, Direction.Right);
            //addEnemy(21, 12, EnemyType.Frogger, Direction.Right);
            //addEnemy(36, 12, EnemyType.Frogger, Direction.Left);
            //addEnemy(6, 13, EnemyType.Murtle, Direction.Left); //26,13
            //addEnemy(26, 13, EnemyType.Smurtle, Direction.Left); //26,13
            //addEnemy(15, 9, EnemyType.MadAx, Direction.Left); //26,13
            //addEnemy(0, 8, EnemyType.MoFoBoom, Direction.Left); //26,13
            //addEnemy(4, 1, EnemyType.Ceiler, Direction.None);//44,1
            //addEnemy(57, 3, EnemyType.Ceiler, Direction.None);
            //addEnemy(65, 3, EnemyType.Hustler, Direction.None);
            //addEnemy(74, 3, EnemyType.Ceiler, Direction.None);

            foreach (Enemy enemy in enemyList)
                enemy.Initialize();

        }

        /// <summary>
        /// Loads the spritesheet.
        /// Loads any graphic related content for all the enemies. 
        /// (Since they all use spritesheet, its more to do with initializing their rectangles).
        /// </summary>
        public void LoadContent()
        {
            base.LoadContent();

            enemySpriteSheet.Load();
            LoadAnimations();
        }

        private void LoadAnimations()
        {
            SpriteAnimation.GetInstance().LoadAnimation("TurretE", SpriiteSheet, 15, 3);
            SpriteAnimation.GetInstance().LoadAnimation("TurretW", SpriiteSheet, 12, 3);

            SpriteAnimation.GetInstance().LoadAnimation("FroggerE", SpriiteSheet, 4, 2);
            SpriteAnimation.GetInstance().LoadAnimation("FroggerW", SpriiteSheet, 0, 2);

            SpriteAnimation.GetInstance().LoadAnimation("MadAxE", SpriiteSheet, 21, 3);
            SpriteAnimation.GetInstance().LoadAnimation("MadAxW", SpriiteSheet, 18, 3);

            SpriteAnimation.GetInstance().LoadAnimation("CeilerE", SpriiteSheet, 9, 3);
            SpriteAnimation.GetInstance().LoadAnimation("CeilerW", SpriiteSheet, 6, 3);

            SpriteAnimation.GetInstance().LoadAnimation("MoFoBoomE", SpriiteSheet, 27, 3);
            SpriteAnimation.GetInstance().LoadAnimation("MoFoBoomW", SpriiteSheet, 24, 3);
        }

        #endregion

        #region Update

        /// <summary>
        /// 1. Activates the enemies within the viewport.
        /// 2. Tells those enemies to fire.
        /// 3. Update the enemy status.
        /// 4. Checks for any hit done to the player and updates player's health accordingly.
        /// OR
        /// 1. Activates enemies based on player's viewport
        /// 2. Updates Active enemies.
        /// </summary>
        /// <param name="gameTime">Snapshot of the game-time</param>
        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);

            ActivateEnemies();

            foreach (Enemy enemy in enemyList)
                enemy.Update(gameTime);

            foreach (Enemy enemy in enemyList)
            {
                if (enemy.BoundingBox.Intersects(player.BoundingBox))
                    player.UpdateHealth(enemy.Damage);

                foreach (Bullet bullet in enemy.BulletList)
                {
                    if (bullet.BoundingBox.Intersects(player.BoundingBox)) 
                    {
                        // sound => Player takes hit.." AOuWww"
                        SoundDJ.GetInstance().PlayCue("punch");
                        player.UpdateHealth( player.Shield == true ? bullet.Damage/4 : bullet.Damage);
                        bullet.Active = false;
                    }
                }
            }
        }

        #endregion

        #region Draw

        /// <summary>
        /// Draws enemy if they are active
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);

            foreach (Enemy enemy in enemyList)
            {
                enemy.drawFunc(gameTime);
                enemy.DrawBullets(gameTime);
            }

        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Adds a new enemy to enemyArray[] at index.
        /// Initializes the position of the enemy to be at x , y (corresponding to World.mapArray Grid)
        /// Also, Initialise any other enemy details here.
        /// </summary>
        /// <param name="x">X coordinate in terms of world.mapArray grid</param>
        /// <param name="y">Y coordinate in terms of world.mapArray grid</param>
        /// <param name="enemyType">Determines what type of enemy to be added</param>
        /// <param name="direction">Direction in which the enemy faces initially</param>
        private void addEnemy(int x, int y, EnemyType enemyType, Direction direction)
        {
            //IF enemytype is specified, then make that type of enemy.
            Enemy drone;

            switch (enemyType)
            {
                case EnemyType.Turret:
                    drone = new Turret(Game, this, new Vector2(x, y), direction);                   
                    break;

                case EnemyType.Frogger:
                    drone = new Frogger(Game, this, new Vector2(x, y), direction);
                    break;

                case EnemyType.Murtle:
                    drone = new Murtle(Game, this, new Vector2(x, y), direction);
                    break;

                case EnemyType.Smurtle:
                    drone = new Smurtle(Game, this, new Vector2(x, y), direction);
                    break;

                case EnemyType.MadAx:
                    drone = new MadAx(Game, this, new Vector2(x, y), direction);
                    break;

                case EnemyType.MoFoBoom:
                    drone = new MoFoBoom(Game, this, new Vector2(x, y), direction);
                    break;

                case EnemyType.Ceiler:
                    drone = new Ceiler(Game, this, new Vector2(x, y), direction);
                    break;

                //case EnemyType.Hustler:
                //    drone = new Hustler(x, y, direction, enemySpriteSheet, this);
                //    break;

                default:
                    drone = new Turret(Game, this, new Vector2(x, y), direction);
                    break;
            }
            enemyList.Add(drone);
        }

        /// <summary>
        /// Activates all those enemies which are within the current viewport.
        /// </summary>
        private void ActivateEnemies()
        {
            foreach(Enemy enemy in enemyList)
            {
                if (world.withinViewPort(enemy.WorldPosition))
                    enemy.Active = true;
                else
                    enemy.Active = false;
            }
        }

        #endregion
                
    }

    enum EnemyType
    {
        Turret,
        Frogger,
        Murtle,
        Smurtle,
        Hustler,
        Ceiler,
        MadAx,
        MoFoBoom
    }
}
