﻿//#region Using Statements
//using System;
//using System.Collections.Generic;
//using System.Text;

//using Microsoft.Xna.Framework;
//using Microsoft.Xna.Framework.Graphics;

//using Library.SpriteBoard;

//using Ladder.GameObjects;
//using Ladder.PC;

//#endregion

//namespace Ladder.NPC
//{
//    class Hustler : Enemy
//    {
//        #region Fields

//        Vector2 velocity;

//        Ammo[] bullets;

//        float reloadingTime = 0.0f;

//        float angle;
//        float alpha;
//        float angleB;
//        float beta;
//        float sinBeta;
//        float cosBeta;

//        #endregion

//        #region Properties

//        private int Sign
//        {
//            get
//            {
//                switch (faceDirection)
//                {
//                    case Direction.Left:
//                        return -1;
//                    case Direction.Right:
//                        return 1;
//                    default: return 0;
//                }
//            }
//        }

//        public override bool Destroyed
//        {
//            get { return destroyed; }
//            set
//            {
//                if (true == value)
//                {
//                    master.Enemies.Remove(this);
//                    master.World.setMapVal(PositionGrid, 0);
//                    master.Player.Victory = VictoryState.Victorious;
//                }

//                destroyed = value;
//            }
//        }

//        public override Rectangle BoundingBox
//        {
//            get
//            {
//                return new Rectangle((int)position.X, (int)position.Y, 120, 48);
//            }
//        }

//        #endregion

//        #region Initialization

//        public Hustler(int x, int y, Direction dirn, SpriteSheet spriteSheet, BotPlayer master)
//            : base(x, y, dirn, spriteSheet, master)
//        {
//            health = Constants.Hustler_Health;
//        }

//        /// <summary>
//        /// Loads the appropriate texture rectangle
//        /// </summary>
//        public override void Load()
//        {
//            texRectangle = SpriteRectangle();
//        }

//        /// <summary>
//        /// Assigns the position of the turret on the grid.
//        /// Initializes three bullets
//        /// </summary>
//        public override void Initialize()
//        {
//            bullets = new Ammo[3];

//            for (int index = 0; index < bullets.Length; index++)
//            {
//                bullets[index] = new Ammo(AmmoType.Bullet, position, parentSpriteSheet);
//            }

//            reloadingTime = Constants.Turret_ReloadTime;      //starts firing as soon as it is activated

//            angle = 30;

//            beta = -angleB * ((float)Math.PI / 180.0f); //(Math.PI/180) converts Degree Value into Radians
//            sinBeta = (float)Math.Sin(beta);
//            cosBeta = (float)Math.Cos(beta);
            
//        }

//        #endregion

//        #region Update

//        public override void Update(GameTime gameTime, IPlayer player)
//        {
//            //UpdateHealthRect(gameTime,);
//            UpdateBullet(gameTime);
//        }
                
//        private void UpdateBullet(GameTime gameTime)
//        {
//            foreach (Ammo bullet in bullets)
//            {
//                if (bullet.Active)
//                {
//                    if (!bullet.Dead())
//                    {
//                        alpha = angle * ((float)Math.PI / 180);

//                        float cosAlpha = (float)Math.Cos(alpha);
//                        float sinAlpha = (float)Math.Sin(alpha);

//                        float X = (Constants.Boomerang_A * cosAlpha * cosBeta -
//                                    Constants.Boomerang_B * sinAlpha * sinBeta);

//                        float Y = (Constants.Boomerang_A * cosAlpha * sinBeta + 
//                                    Constants.Boomerang_B * sinAlpha * cosBeta);

//                        angle += .1f;

//                        bullet.PositionX += (X/1.0f);
//                        bullet.PositionY += Y;

//                        //angle = MathHelper.Clamp(angle, 0, 360);
//                    }
//                }
//            }
//        }

//        #endregion

//        #region Draw

//        public override void Draw(GameTime gameTime, int ViewPortX)
//        {
//            if (active &&
//                PositionGrid.X >= ViewPortX &&
//                PositionGrid.X < ViewPortX + Constants.viewPortWidth)
//            {
//                Rectangle destRectangle = new Rectangle(
//                                            ((PositionGrid.X - ViewPortX) * parentSpriteSheet.TileWidth),
//                                            PositionGrid.Y * parentSpriteSheet.TileHeight,
//                                            texRectangle.Width, parentSpriteSheet.TileHeight);

//                GamePlayState.SSpriteBatch.Draw(parentSpriteSheet.SpriteSheeet,
//                                    destRectangle, texRectangle, Color.White);
//            }

//            DrawBullets(ViewPortX);
//        }

//        private void DrawBullets(int ViewPortX)
//        {
//            foreach (Ammo bullet in bullets)
//            {
//                if (bullet.Active)
//                {
//                    Rectangle destRectangle = new Rectangle(
//                                            (int)(bullet.PositionX - (ViewPortX * parentSpriteSheet.TileWidth)),
//                                            (int)(bullet.PositionY),
//                                            parentSpriteSheet.TileWidth, parentSpriteSheet.TileHeight);

//                    GamePlayState.SSpriteBatch.Draw(parentSpriteSheet.SpriteSheeet,
//                        destRectangle, parentSpriteSheet.getTextureRectangle(2), Color.White);
//                }
//            }
//        }

//        #endregion

//        #region Helper Methods

//        /// <summary>
//        /// Depending on the direction of the turret, corresponding texture rectangle is returned
//        /// </summary>
//        /// <returns></returns>
//        protected override Rectangle SpriteRectangle()
//        {
//            texRectangle = new Rectangle( 
//                parentSpriteSheet.getTextureRectangle(10).X,
//                parentSpriteSheet.getTextureRectangle(10).Y,
//                120,parentSpriteSheet.TileHeight);
//            return texRectangle;
//        }

//        public override void Shoot(Ladder.PC.IPlayer player, GameTime gameTime)
//        {
//            Ammo bullet = LoadBullet(gameTime);
//            if (bullet != null)
//                bullet.VelocityX = (-2.0f);

//            //if (
//            //    (player.WorldPosition.Y >= (positionGrid.Y - 1)) &&
//            //    (player.WorldPosition.Y <= (positionGrid.Y + 1))
//            //    )
//            //{
//            //    switch (direction)
//            //    {
//            //        case Direction.Left:
//            //            {
//            //                if (player.WorldPosition.X < positionGrid.X)
//            //                {
//            //                    //shoot
//            //                    Ammo bullet = LoadBullet(gameTime);
//            //                    if (bullet != null)
//            //                        bullet.VelocityX = (-2.0f);
//            //                }
//            //                break;
//            //            }

//            //        case Direction.Right:
//            //            {
//            //                if (player.WorldPosition.X > positionGrid.X)
//            //                {
//            //                    //shoot
//            //                    Ammo bullet = LoadBullet(gameTime);
//            //                    if (bullet != null)
//            //                        bullet.VelocityX = 2.0f;
//            //                }
//            //                break;
//            //            }

//            //        default:
//            //            break;
//            //    }
//            //}
//        }

//        /// <summary>
//        /// Selects the inactive bullet from the stocked ammo.
//        /// </summary>
//        /// <returns>Ammo that is currently inactive</returns>
//        private Ammo LoadBullet(GameTime gameTime)
//        {
//            reloadingTime += (float)gameTime.ElapsedGameTime.Milliseconds;

//            if (reloadingTime > Constants.Turret_ReloadTime)
//            {
//                reloadingTime = 0.0f;

//                foreach (Ammo bullet in bullets)
//                    if (!bullet.Active)
//                    {
//                        bullet.Active = true;
//                        return bullet;
//                    }
//            }
//            return null;
//        }

//        /// <summary>
//        /// Checks if a bullet hits player.
//        /// Disables the bullet
//        /// (todo) Add explosion code
//        /// </summary>
//        /// <param name="player">player against whom hit is accounted</param>
//        /// <returns>Amount of damage. 0 if no damage</returns>
//        public override int CheckForHit(IPlayer player)
//        {
//            foreach (Ammo bullet in bullets)
//            {
//                if (bullet.Active)
//                {
//                    if (player.BoundingBox.Intersects(bullet.BoundingBox))
//                    {
//                        bullet.Active = false;

//                        if (player.Shield)
//                        {
//                            return bullet.Damage / 4;
//                        }
//                        //initiate explosion

//                        return bullet.Damage;
//                    }
//                }
//            }
//            return 0;
//        }

//        /// <summary>
//        /// Checks to see if any of the bullets have hit any of the turrets, 
//        /// after being deflected by the player.
//        /// </summary>
//        public override void CheckFriendlyFire(Dictionary<Enemy, int> friendFire)
//        {
//            foreach (Ammo bullet in bullets)
//            {
//                if (bullet.Active && bullet.Deflected)
//                {
//                    foreach (Enemy friend in master.Enemies)
//                    {
//                        if (friend.BoundingBox.Intersects(bullet.BoundingBox))
//                        {
//                            //update enemies health
//                            //friend.updateHealth(bullet.Damage);
//                            if (friendFire.ContainsKey(friend))
//                            {
//                                friendFire[friend] += bullet.Damage;
//                            }
//                            else
//                                friendFire.Add(friend, bullet.Damage);

//                            bullet.Active = false;
//                        }
//                    }
//                }
//            }
//        }

//        protected override void UpdateHealthRect(GameTime gameTime)
//        {
//            goodHealthRect.X = (int)(position.X - (master.World.ViewPortX * Constants.TileWidth) + 0);
//            goodHealthRect.Y = (int)(position.Y + 0);

//            goodHealthRect.Width = Constants.Hustler_HealthBar_Width;
//            goodHealthRect.Height = Constants.Hustler_Height;

//            badHealthRect.X = goodHealthRect.X;
//            badHealthRect.Width = goodHealthRect.Width;

//            int h = (int)(((float)Health / Constants.Hustler_Health) * Constants.Hustler_Height);
//            badHealthRect.Y = goodHealthRect.Y + h;
//            badHealthRect.Height = Constants.Hustler_Height - h;
//        }
//        #endregion

//    }
//}
