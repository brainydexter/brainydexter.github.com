#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;

using Ladder.GameObjects;
using Ladder.PC;

#endregion

namespace Ladder.NPC
{
    class Turret : Enemy
    {
        #region Fields

        DrawGame draw;
        protected float reloadingTime = 0.0f;

        #endregion

        #region Initialization

        /// <summary>
        /// Initializes the health and tile Number that the turret would use from the enemy spritesheet.
        /// </summary>
        /// <param name="game"></param>
        /// <param name="boss"></param>
        /// <param name="posn"></param>
        /// <param name="facingDirn"></param>
        public Turret(Game game, BotPlayer boss, Vector2 posn, Direction facingDirn)
            : base(game,boss,posn,facingDirn)
        {
            health = Constants.Turret_Health;
            damage = Constants.Turret_Body_Damage;

            tileNumber = (faceDirection == Direction.Left) ? 12 : 17;
        }

        /// <summary>
        /// Assigns the position of the turret on the grid.
        /// Initializes three bullets
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();

            drawFunc = base.DrawEnemy;

            for (int i = 0; i < 1; i++)
                bulletList.Add(new Bullet(Game, spriteSheet,Constants.Turret_Bullet_Tile));

            reloadingTime = Constants.Turret_ReloadTime;      //starts firing as soon as it is activated
        }

        #endregion

        #region Update

        /// <summary>
        /// shoots if active.
        /// updates the bullet
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Update(GameTime gameTime)
        {
            if(Active)
                if (player.WorldPosition.Y >= worldPosition.Y - 1 && player.WorldPosition.Y <= worldPosition.Y + 1)
                    Shoot(gameTime);

            foreach (Bullet bullet in bulletList)
                bullet.Update(gameTime);
        }
        
        #endregion

        #region Helper Methods

        /// <summary>
        /// if the player is within the turret's height-range, this method is called.
        /// </summary>
        /// <param name="gameTime"></param>
        protected virtual void Shoot(GameTime gameTime)
        {
            switch (faceDirection)
            {
                case Direction.Left:
                    {
                        if (player.WorldPosition.X < worldPosition.X)
                        {
                            //shoot
                            Bullet bullet = LoadBullet(gameTime);
                            if (bullet != null)
                                bullet.Fire(worldPosition , new Vector2(player.WorldPosition.X, worldPosition.Y),TrajectoryType.Straight);
                        }
                        break;
                    }
                case Direction.Right:
                    {
                        if (player.WorldPosition.X > worldPosition.X)
                        {
                            //shoot
                            Bullet bullet = LoadBullet(gameTime);
                            if (bullet != null)
                                bullet.Fire(worldPosition, new Vector2(player.WorldPosition.X, worldPosition.Y),TrajectoryType.Straight);
                        }
                        break;
                    }
                default:
                    break;
            }
        }

        /// <summary>
        /// Selects the inactive bullet from the stocked ammo.
        /// </summary>
        /// <returns>Bullet that is currently inactive</returns>
        protected Bullet LoadBullet(GameTime gameTime)
        {
            reloadingTime += (float)gameTime.ElapsedGameTime.Milliseconds;

            if (reloadingTime > Constants.Turret_ReloadTime)
            {
                reloadingTime = 0.0f;

                foreach (Bullet bullet in bulletList)
                    if (!bullet.Active)
                    {
                        bullet.Active = true;

                        drawFunc = Draw;

                        return bullet;
                    }
            }
            return null;
        }

        #endregion

        public override void Draw(GameTime gameTime)
        {
            string animString = "Turret";

            if (faceDirection == Direction.Right)
                animString += "E";
            else if (faceDirection == Direction.Left)
                animString += "W";
            else
                animString += "E";

            bool completed = false;

            world.DrawOnScreen(SpriteAnimation.GetInstance().PlayAnimation(animString, out completed), worldPosition, spriteSheet);

            if(completed)
                drawFunc = base.DrawEnemy;
        }
       
    }

   
}
