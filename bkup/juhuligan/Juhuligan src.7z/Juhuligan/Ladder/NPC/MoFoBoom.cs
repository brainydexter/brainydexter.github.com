﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;

using Ladder.GameObjects;
using Ladder.PC;

#endregion

namespace Ladder.NPC
{
    class MoFoBoom : Enemy
    {
        float reloadingTime = 0f;

        public MoFoBoom(Game game, BotPlayer boss, Vector2 posn, Direction direction)
            : base(game, boss, posn, direction)
        {
            tileNumber = 27;

            health = Constants.MoFoBoom_Health;
            damage = Constants.MoFoBoom_BodyDamage;
        }

        public override void Initialize()
        {
            base.Initialize();

            for (int i = 0; i < 1; i++)
                bulletList.Add(new Bullet(Game, spriteSheet, Constants.MoFoBoom_Bullet_Tile));

            reloadingTime = Constants.MoFoBoom_ReloadTime;
        }

        public override void Update(GameTime gameTime)
        {
            if (Active)
                Shoot(gameTime);

            foreach (Bullet bullet in bulletList)
                bullet.Update(gameTime);
        }

        /// <summary>
        /// if the player is within the turret's height-range, this method is called.
        /// </summary>
        /// <param name="gameTime"></param>
        protected void Shoot(GameTime gameTime)
        {
            Bullet bullet = LoadBullet(gameTime);
            if (bullet != null)
                bullet.Fire(worldPosition, new Vector2(player.WorldPosition.X, worldPosition.Y), TrajectoryType.Boomerang);
        }

        /// <summary>
        /// Selects the inactive bullet from the stocked ammo.
        /// </summary>
        /// <returns>Bullet that is currently inactive</returns>
        private Bullet LoadBullet(GameTime gameTime)
        {
            reloadingTime += (float)gameTime.ElapsedGameTime.Milliseconds;

            if (reloadingTime > Constants.MoFoBoom_ReloadTime)
            {
                reloadingTime = 0.0f;

                foreach (Bullet bullet in bulletList)
                    if (!bullet.Active)
                    {
                        bullet.Active = true;

                        drawFunc = Draw;
                        return bullet;
                    }
            }
            return null;
        }

        public override void Draw(GameTime gameTime)
        {
            string animString = "MoFoBoomE";

            //if (player.WorldPosition.X - worldPosition.X > 0)
            //    animString += "E";
            //else
            //    animString += "W";

            bool completed = false;

            world.DrawOnScreen(SpriteAnimation.GetInstance().PlayAnimation(animString, out completed), worldPosition, spriteSheet);

            if (completed)
                drawFunc = base.DrawEnemy;
        }
    }
}
