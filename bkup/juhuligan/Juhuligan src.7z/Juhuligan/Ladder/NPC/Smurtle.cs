﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;

using Ladder.GameObjects;
using Ladder.PC;

#endregion

namespace Ladder.NPC
{
    class Smurtle : Murtle
    {
        public Smurtle(Game game, BotPlayer boss, Vector2 posn, Direction facingDirn)
            : base(game, boss, posn, facingDirn)
        {
        }

        public override void Update(Microsoft.Xna.Framework.GameTime gameTime)
        {
            if (Active)
            {
                float vel = (player.WorldPosition.X - worldPosition.X) * 0.01f;
                if (Math.Abs(velocity.X) < Math.Abs(vel))
                    velocity.X = vel;

                base.Update(gameTime);
            }
        }
    }
}
