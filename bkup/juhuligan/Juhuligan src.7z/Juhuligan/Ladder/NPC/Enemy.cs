#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;

using Ladder.PC;
using Ladder.GameObjects;
using Ladder.GameStates.GameMenu.PlayGameMenu;
using Library.AudioNS;
#endregion

namespace Ladder.NPC
{
    /// <summary>
    /// Represents Single Enemy class.
    /// Based on the enemyType and direction, texRectangle is initialised to the rectangle from BotPlayer
    /// (a.k.a EnemyManager) SpriteSheet.
    /// OR
    /// To make a new enemy:
    /// 1. override constructor for tileNumber, enemy health and the body damage that it does.
    /// 2. Add bullets or any other extras in Initialize() and call the base initialize, if needed.
    /// 3. Override update for shooting etc.
    /// 4. 
    /// override the Update/Draw method as needed.
    /// </summary>
    abstract class Enemy : GameObject
    {
       
        #region Fields

        protected List<Bullet> bulletList;
        protected int damage;                 //for enemies like logger

        protected Direction faceDirection;
        
        protected int health;
        
        protected IPlayer player;
        protected BotPlayer master;

        protected bool active;
        protected bool destroyed;

        public DrawGame drawFunc;

        #endregion

        #region Properties

        /// <summary>
        /// Damage offered by the enemy body itself
        /// </summary>
        public int Damage
        {
            get { return damage; }
        }

        public int Health
        {
            get { return health; }
        }

        public virtual bool Destroyed
        {
            get { return destroyed; }
            set 
            {
                if (true == value)
                {
                    master.Enemies.Remove(this);
                    //world.setMapVal(worldPosition, 0);
                }
                
                destroyed = value; 
            }
        }

        public bool Active
        {
            get
            {
                return active;
            }
            set
            {
                active = value;
            }
        }

        public Vector2 WorldPosition
        {
            get { return worldPosition; }
        }

        public List<Bullet> BulletList
        {
            get { return bulletList; }
        }

        #endregion

        #region Initialization

        /// <summary>
        /// Initializes the worldPosition, health, facing direction and enemy body damage.
        /// Sets active to false, and destroyed to false.
        /// Override tileNumber, health and enemy body damage.
        /// </summary>
        /// <param name="game">Current Game</param>
        /// <param name="boss">Botplayer manager</param>
        /// <param name="posn">World Position</param>
        /// <param name="facingDirn">If the enemy faces in any given direction</param>
        public Enemy(Game game, BotPlayer boss, Vector2 posn, Direction facingDirn)
            : base(game)
        {
            master = boss;

            spriteSheet = master.SpriiteSheet;

            worldPosition = posn;

            faceDirection = facingDirn;

            bulletList = new List<Bullet>();
            health = 100;

            Active = false;
            Destroyed = false;
        }

        /// <summary>
        /// Refernces to the human player
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();
            player = master.Player;

            drawFunc = Draw;
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Updates enemies health with damage
        /// </summary>
        /// <param name="damage"></param>
        public void updateHealth(int damage)
        {
            if (health - damage <= 0)
            {
                SoundDJ.GetInstance().PlayCue("kill");
                health = 0;
                Destroyed = true;
            }
            else
            {
                health -= damage;
            }
        }

        #endregion

        public override void Draw(GameTime gameTime)
        {
            if (Active)
            {
                base.Draw(gameTime);

                foreach (Bullet bullet in bulletList)
                    if (bullet.Active)
                        bullet.Draw(gameTime);
            }
        }

        public void DrawEnemy(GameTime gameTime)
        {
            if (Active)
            {
                base.Draw(gameTime);
            }
        }

        public void DrawBullets(GameTime gameTime)
        {
            foreach (Bullet bullet in bulletList)
                if (bullet.Active)
                    bullet.Draw(gameTime);
        }
    }

    public delegate void DrawGame(GameTime gameTime);
}
