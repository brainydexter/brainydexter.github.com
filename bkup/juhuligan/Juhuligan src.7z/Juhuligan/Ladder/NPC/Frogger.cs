#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;

using Ladder.GameObjects;
using Ladder.PC;

#endregion

namespace Ladder.NPC
{
    class Frogger : Enemy
    {
        #region Fields

        float reloadingTime = 0.0f;

        #endregion

        #region Initialization

        public Frogger(Game game, BotPlayer boss, Vector2 posn, Direction facingDirn)
            : base(game, boss, posn, facingDirn)
        {
            health = Constants.Frogger_Health;
            damage = Constants.Frogger_Body_Damage;
            tileNumber = Constants.Frogger_Body_Tile;
        }

        /// <summary>
        /// Assigns the position of the turret on the grid.
        /// Initializes three bullets
        /// </summary>
        public override void Initialize()
        {
            base.Initialize();

            for (int i = 0; i < 3; i++)
                bulletList.Add(new Bullet(Game, spriteSheet, Constants.Frogger_Bullet_Tile));

            reloadingTime = Constants.Turret_ReloadTime;      //starts firing as soon as it is activated

            //rotation = 0.0f;
        }

        #endregion

        #region Update

        public override void Update(GameTime gameTime)
        {
            if (Active)
               Shoot(gameTime);

            foreach (Bullet bullet in bulletList)
                bullet.Update(gameTime);
        }

        #endregion

        #region Helper Methods

        protected void Shoot(GameTime gameTime)
        {
            switch (faceDirection)
            {
                case Direction.Left:
                    {
                        if (player.WorldPosition.X < worldPosition.X)
                        {
                            //shoot
                            Bullet bullet = LoadBullet(gameTime);
                            if (bullet != null)
                            {
                                bullet.Fire(worldPosition, player.WorldPosition,TrajectoryType.LeapFrog);
                            }
                        }
                        break;
                    }

                case Direction.Right:
                    {
                        if (player.WorldPosition.X > worldPosition.X)
                        {
                            //shoot
                            Bullet bullet = LoadBullet(gameTime);
                            if (bullet != null)
                            {
                                bullet.Fire(worldPosition, player.WorldPosition,TrajectoryType.LeapFrog);
                            }
                        }
                        break;
                    }

                default:
                    break;
            }
        }

        /// <summary>
        /// Selects the inactive bullet from the stocked ammo.
        /// </summary>
        /// <returns>Ammo that is currently inactive</returns>
        private Bullet LoadBullet(GameTime gameTime)
        {
            reloadingTime += (float)gameTime.ElapsedGameTime.Milliseconds;

            if (reloadingTime > Constants.Frogger_ReloadTime)
            {
                reloadingTime = 0.0f;

                foreach (Bullet bullet in bulletList)
                    if (!bullet.Active)
                    {
                        bullet.Active = true;

                        drawFunc = Draw;

                        return bullet;
                    }
            }
            return null;
        }

        #endregion

        public override void Draw(GameTime gameTime)
        {
            string animString = "Frogger";

            if (faceDirection == Direction.Right)
                animString += "E";
            else
                animString += "W";

            bool completed = false;

            world.DrawOnScreen(SpriteAnimation.GetInstance().PlayAnimation(animString, out completed), worldPosition, spriteSheet);

            if (completed)
                drawFunc = base.DrawEnemy;
        }
    }
}
