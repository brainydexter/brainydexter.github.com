﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;

using Ladder.GameObjects;
using Ladder.PC;

#endregion

namespace Ladder.NPC
{
    class MadAx : Enemy
    {
        float reloadingTime = 0f;
        float walkTime = 0f;
        Direction prevDirn;
        Direction currDirn;
        Rectangle boundingRegion;

        public MadAx(Game game, BotPlayer boss, Vector2 posn, Direction direction)
            : base(game, boss, posn, direction)
        {
            tileNumber = 18;

            health = Constants.MadAx_Health;
            damage = Constants.MadAx_BodyDamage;
        }

        public override void Initialize()
        {
            base.Initialize();

            for (int i = 0; i < 5; i++)
                bulletList.Add(new Bullet(Game, spriteSheet, Constants.MadAx_Bullet_Tile));

            reloadingTime = Constants.MadAx_ReloadTime;

            boundingRegion = new Rectangle((int)worldPosition.X - 1, (int)worldPosition.Y - 1, 2, 2);
        }

        public override void Update(GameTime gameTime)
        {
            if (Active)
            {
                Walk1(gameTime);
                Shoot(gameTime);   
            }

            foreach (Bullet bullet in bulletList)
                bullet.Update(gameTime);
        }

        private void Walk1(GameTime gameTime)
        {
            walkTime += (float)gameTime.ElapsedGameTime.Milliseconds;

            if (walkTime > Constants.MadAx_ReloadTime / 1)
            {
                walkTime = 0f;
                currDirn = (Direction)(1 << new Random().Next(0, 4));
            }

            switch (currDirn)
            {
                case Direction.Left: velocity.X = -0.02f;
                    break;

                case Direction.Right: velocity.X = 0.02f;
                    break;

                case Direction.Up:
                    if (prevDirn != currDirn)
                    {
                        velocity.Y = -0.3f;
                    }
                    break;

                default: break;
            }
                
            velocity.Y += 0.01f;

            cageMadAx();
            if ((base.Move() & Direction.Down) != 0)
            {
                velocity.Y = 0;
                prevDirn = Direction.None;
            }

            if ((currDirn & Direction.Up) != 0)
            {
                prevDirn = currDirn;
            }
        }

        private void cageMadAx()
        {
            if (worldPosition.X + velocity.X < boundingRegion.Left)
                velocity.X = 0f;//0.2f;
            else if (worldPosition.X + velocity.X > boundingRegion.Right)
                velocity.X = 0f;//-0.2f;
        }

        /// <summary>
        /// if the player is within the turret's height-range, this method is called.
        /// </summary>
        /// <param name="gameTime"></param>
        protected void Shoot(GameTime gameTime)
        {
            Bullet bullet = LoadBullet(gameTime);
            if (bullet != null)
                bullet.Fire(worldPosition, new Vector2(player.WorldPosition.X, worldPosition.Y), TrajectoryType.Quartere);
        }

        /// <summary>
        /// Selects the inactive bullet from the stocked ammo.
        /// </summary>
        /// <returns>Bullet that is currently inactive</returns>
        private Bullet LoadBullet(GameTime gameTime)
        {
            reloadingTime += (float)gameTime.ElapsedGameTime.Milliseconds;

            if (reloadingTime > Constants.MadAx_ReloadTime)
            {
                reloadingTime = 0.0f;

                foreach (Bullet bullet in bulletList)
                    if (!bullet.Active)
                    {
                        bullet.Active = true;
                        drawFunc = Draw;

                        return bullet;
                    }
            }
            return null;
        }

        public override void Draw(GameTime gameTime)
        {
            string animString = "MadAx";

            if (velocity.X > 0)
                animString += "E";
            else 
                animString += "W";

            bool completed = false;

            world.DrawOnScreen(SpriteAnimation.GetInstance().PlayAnimation(animString, out completed), worldPosition, spriteSheet);

            //if (completed)
            //    drawFunc = base.DrawEnemy;
        }

    }
}
