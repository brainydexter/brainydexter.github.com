﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteSheetNS;

using Ladder.GameObjects;
using Ladder.PC;

#endregion

namespace Ladder.NPC
{
    class Murtle : Enemy
    {
        #region Initialization

        public Murtle(Game game, BotPlayer boss, Vector2 posn, Direction facingDirn)
            : base(game, boss, posn, facingDirn)
        {
            health = Constants.Lumber_Health;
            damage = Constants.Lumber_Damage;

            tileNumber = 3;

            velocity = new Vector2(2.0f, 0.0f);
        }

        #endregion

        #region Update

        public override void Update(GameTime gameTime)
        {
            if (Active)
            {
                Direction hitDirn = base.Move();
                if ((hitDirn & Direction.Left) != 0)
                    velocity.X = 0.02f;
                else if ((hitDirn & Direction.Right) != 0)
                    velocity.X = -0.02f;

                worldPosition += velocity;
            }
        }

        #endregion

    }
}
