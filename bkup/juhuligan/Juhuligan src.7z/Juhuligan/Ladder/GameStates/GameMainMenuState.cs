﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

using Ladder.GameStates.GameMenu;

namespace Ladder.GameStates
{
    public class GameMainMenuState : IGameState
    {
        Texture2D menuBackground;

        public bool exitGame = false;

        List<ACMenuState> menuItemsList;
        int currentState = 0;

        public Stack<ACMenuState> mainMenuStack;

        public bool initialized = false;
        public GameManager gameStateMgr;

        public GameMainMenuState(GameManager menuMgr)
        {
            gameStateMgr = menuMgr;
            menuItemsList = new List<ACMenuState>();

            mainMenuStack = new Stack<ACMenuState>();

        }

        public void Initialize()
        {
            int posnY = (int)(Constants.WindowHeight * 0.5);
            int posnX = (int)(Constants.WindowWidth * 0.5) - 100;

            menuItemsList.Add(new PlayGameMenuItem(this, "Play Game", new Vector2(posnX, posnY)));
            menuItemsList.Add(new CreditsMenuItem(this, "Credits", new Vector2(posnX, posnY += 50)));
            //menuItemsList.Add(new OptionsMenuItem(this, "Options", new Vector2(400, 150)));
            menuItemsList.Add(new ExitMenuItem(this, "Exit Game", new Vector2(posnX, posnY += 50)));

            foreach (ACMenuState menuItem in menuItemsList)
                menuItem.Initialize();
        }

        public void LoadContent()
        {
            menuBackground = gameStateMgr.Content.Load<Texture2D>("menu");

            foreach (ACMenuState menuItem in menuItemsList)
                menuItem.LoadContent();

            initialized = true;
        }

        public UpdateAction Update(GameTime gameTime)
        {
            if (exitGame)
            {
                gameStateMgr.SetState(gameStateMgr.gameEndState);
                return UpdateAction.Remove;
            }

            if (mainMenuStack.Count == 0)
            {
                if(gameStateMgr.input.KeyJustPressed(Keys.Down))
                    currentState = (currentState + 1) % menuItemsList.Count;
                else if (gameStateMgr.input.KeyJustPressed(Keys.Up))
                {
                    if (currentState - 1 < 0)
                        currentState = menuItemsList.Count - 1;
                    else
                        currentState--;
                }
                else if (gameStateMgr.input.KeyJustPressed(Keys.Enter))
                {
                    mainMenuStack.Push(menuItemsList[currentState]);
                }
            }
            else
            {
                if (mainMenuStack.Peek().Update(gameTime) == UpdateAction.Remove)
                    mainMenuStack.Pop();
            }
            return UpdateAction.None;
        }

        public void Draw(GameTime gameTime)
        {
            //Draw background
            gameStateMgr.spriteBatch.Begin();
            gameStateMgr.spriteBatch.Draw(menuBackground, Vector2.Zero, Color.White);
            gameStateMgr.spriteBatch.End();

            //Draw menu options if the menu stack is empty, i.e. no other option is selected
            if (mainMenuStack.Count == 0)
            {
                gameStateMgr.spriteBatch.Begin();

                foreach (ACMenuState menuItem in menuItemsList)
                    gameStateMgr.spriteBatch.DrawString(gameStateMgr.font, menuItem.text,
                                                        menuItem.position, Color.Black);

                gameStateMgr.spriteBatch.DrawString(gameStateMgr.font, menuItemsList[currentState].text,
                                                        menuItemsList[currentState].position, Color.Red);

                gameStateMgr.spriteBatch.End();
            }
            else //Draw the selected option
            {
                mainMenuStack.Peek().Draw(gameTime);
            }
        }

        public bool isInitialized()
        {
            return initialized;
        }

       
    }
}
