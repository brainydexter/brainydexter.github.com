﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Ladder.GameStates.GameMenu.PlayGameMenu;

namespace Ladder.GameStates.GameMenu
{
    public class PlayGameMenuItem : ACMenuState
    {
        public GameMainMenuState mainMenuMgr;

        public bool exitGamePlayState = false;
        public bool initialized = false;

        ACPlayState gamePlayState;
        ACPlayState gamePauseState;
        //need to add gameCompletedState;
        ACPlayState currentState;

        public bool Initialized
        {
            get
            {
                if (gamePlayState == null || gamePlayState.Initialized == false)
                    return false;
                else
                    return true;
            }
        }

        public PlayGameMenuItem(GameMainMenuState mainMenuMgr, string text, Vector2 pos)
            : base(text, pos, mainMenuMgr.gameStateMgr)
        {
            this.mainMenuMgr = mainMenuMgr;

            SetState(GetGamePlayState());
        }

        public override void Initialize()
        {
        }               

        public override void LoadContent()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="gameTime"></param>
        /// <returns>UpdateAction.remove if exit was hit at gamePauseState</returns>
        public override UpdateAction Update(Microsoft.Xna.Framework.GameTime gameTime)
        {
            if (!Initialized)
            {
                SetState(GetGamePlayState());
            }
            currentState.Update(gameTime);

            if (exitGamePlayState)
            {
                //resetting fields
                exitGamePlayState = false;

                GetGamePlayState().Initialized = false;
                GetGamePauseState().Initialized = false;

                return UpdateAction.Remove;
            }

            return UpdateAction.None;
        }

        public override void Draw(Microsoft.Xna.Framework.GameTime gameTime)
        {
            currentState.Draw(gameTime);
        }

        public ACPlayState GetGamePauseState()
        {
            if (gamePauseState == null)
                return gamePauseState = new GamePauseState(this);

            if (!gamePauseState.Initialized)
                gamePauseState = new GamePauseState(this);

            return gamePauseState;
        }

        public ACPlayState GetGamePlayState()
        {
            if (gamePlayState == null)
                return gamePlayState =  new GamePlayState(this);

            if (!gamePlayState.Initialized)
                gamePlayState = new GamePlayState(this);

            return gamePlayState;
        }

        public ACPlayState GetGameCompletedState(VictoryState victoryState)
        {
            return new GameCompletedState(this, victoryState);
        }

        public void SetState(ACPlayState state)
        {
            if (!state.Initialized)
            {
                state.Initialize();
                state.LoadContent();
            }

            currentState = state;
        }
    }
}
