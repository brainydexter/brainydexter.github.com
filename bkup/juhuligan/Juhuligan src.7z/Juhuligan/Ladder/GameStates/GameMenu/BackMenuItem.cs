﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Ladder.GameStates.GameMenu
{
    class BackMenuItem : ACMenuState
    {
        GameMainMenuState mainMenuMgr;

        public BackMenuItem(GameMainMenuState mainMenuMgr, string text, Vector2 pos)
            :base(text,pos,mainMenuMgr.gameStateMgr)
        {
            this.text = text;

            this.mainMenuMgr = mainMenuMgr;
        }

        public override void Initialize()
        {
        }

        public override void LoadContent()
        {
        }

        public override UpdateAction Update(GameTime gameTime)
        {
            return UpdateAction.Remove;
        }

        public override void Draw(GameTime gameTime)
        {
            mainMenuMgr.gameStateMgr.spriteBatch.Begin();
            mainMenuMgr.gameStateMgr.spriteBatch.DrawString(mainMenuMgr.gameStateMgr.font, text, position, Color.Black);
            mainMenuMgr.gameStateMgr.spriteBatch.End();
        }

        public bool isInitialized()
        {
            return true;
        }

        internal void Draw(GameTime gameTime, Color color)
        {
            mainMenuMgr.gameStateMgr.spriteBatch.Begin();
            mainMenuMgr.gameStateMgr.spriteBatch.DrawString(mainMenuMgr.gameStateMgr.font, text, position, color);
            mainMenuMgr.gameStateMgr.spriteBatch.End();
        }
    }
}
