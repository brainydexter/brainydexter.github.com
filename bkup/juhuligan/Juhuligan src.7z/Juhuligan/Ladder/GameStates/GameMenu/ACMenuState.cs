﻿using System;
using Microsoft.Xna.Framework;

using Library.InputNS;

namespace Ladder.GameStates.GameMenu
{
    public abstract class ACMenuState
    {
        public string text;
        public Vector2 position;
        protected IMouseHandler input;

        public ACMenuState(string text, Vector2 position, GameManager menuMgr)
        {
            this.text = text;
            this.position = position;

            this.input = menuMgr.input;
        }

        public abstract void Initialize();

        public abstract void LoadContent();

        public abstract UpdateAction Update(GameTime gameTime);

        public abstract void Draw(GameTime gameTime);

      
    }
}
