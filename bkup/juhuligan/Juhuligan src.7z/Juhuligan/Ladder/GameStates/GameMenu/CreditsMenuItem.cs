﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Library.InputNS;

namespace Ladder.GameStates.GameMenu
{
    class CreditsMenuItem : ACMenuState
    {
        GameMainMenuState mainMenuMgr;

        BackMenuItem backMenuItem;

        Texture2D creditsScreen;

        public CreditsMenuItem(GameMainMenuState mainMenuMgr, string text,Vector2 pos)
            : base(text,pos,mainMenuMgr.gameStateMgr)
        {
            this.mainMenuMgr = mainMenuMgr;

            backMenuItem = new BackMenuItem(mainMenuMgr, "Back to Main Menu", new Vector2(150, Constants.WindowHeight * 0.90f));
        }

        public override void Initialize()
        {
        }

        public override void LoadContent()
        {
            creditsScreen = mainMenuMgr.gameStateMgr.Content.Load<Texture2D>("credits");
        }

        public override UpdateAction Update(GameTime gameTime)
        {
            if (input.KeyJustPressed(Keys.Enter))
                return UpdateAction.Remove;

            return UpdateAction.None;
        }

        public override void Draw(GameTime gameTime)
        {
            mainMenuMgr.gameStateMgr.spriteBatch.Begin();
            mainMenuMgr.gameStateMgr.spriteBatch.Draw(creditsScreen, Vector2.Zero, Color.White);
            mainMenuMgr.gameStateMgr.spriteBatch.End();

            backMenuItem.Draw(gameTime, Color.Red);
        }

        public bool isInitialized()
        {
            return true;
        }
    }
}
