﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Ladder.GameStates.GameMenu
{
    class ReturnToGamePauseItem : ACMenuState
    {
        GameMainMenuState mainMenuMgr;

        public ReturnToGamePauseItem(GameMainMenuState mainMenuMgr, string text, Vector2 pos)
            : base(text, pos, mainMenuMgr.gameStateMgr)
        {
            this.mainMenuMgr = mainMenuMgr;
        }

        public override void Initialize()
        {
        }

        public override void LoadContent()
        {
        }

        public override UpdateAction Update(GameTime gameTime)
        {
            return UpdateAction.None;
        }

        public override void Draw(GameTime gameTime)
        {
        }

        public bool isInitialized()
        {
            return true;
        }
    }
}
