﻿#region Using Statements

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

using Library.InputNS;
using Ladder.WorldNS;
using Ladder.GameObjects;

using Ladder.NPC;
using Ladder.PC;
using Ladder.Resources;

using Ladder.UI;
using Library.AudioNS;
#endregion

namespace Ladder.GameStates.GameMenu.PlayGameMenu
{
    public class GamePlayState : ACPlayState
    {
        #region Fields

        Game game;
        GraphicsDeviceManager graphics;
        Texture2D gameScreen;

        static SpriteBatch spriteBatch;
        static SpriteFont font;

        //static int count = 0;

        Player playerBox;
        BotPlayer botPlayer;
        ResourceManager resourceMgr;
        Hud hud;

        World world;

        #endregion

        #region Properties

        public static SpriteBatch SSpriteBatch
        {
            get { return spriteBatch; }
        }

        public static SpriteFont SSpriteFont
        {
            get
            { return font; }
        }

        public override bool Initialized
        {
            get
            {
                return initialized;
            }
            set
            {
                if (value == false)
                    FlushGame();

                initialized = value;
            }
        }

        private void FlushGame()
        {
            LevelLoader.GetInstance(this.game).Dispose();
            //this.world.Dispose();

            //this.resourceMgr.Dispose(); // = null;
            this.game.Services.RemoveService(typeof(IWorld));
            this.game.Services.RemoveService(typeof(IPlayer));
            this.game.Services.RemoveService(typeof(BotPlayer));
            this.game.Services.RemoveService(typeof(ResourceManager));
            this.game.Services.RemoveService(typeof(Hud));
        }
        #endregion

        #region Initialization

        public GamePlayState(PlayGameMenuItem playGameController)
            : base(playGameController)
        {
            game = playGameController.mainMenuMgr.gameStateMgr;
            graphics = playGameController.mainMenuMgr.gameStateMgr.graphics;
            spriteBatch = playGameController.mainMenuMgr.gameStateMgr.spriteBatch;
            font = playGameController.mainMenuMgr.gameStateMgr.font;

            //world should be made before player
            world = new World(game, Constants.LevelPath, Constants.TileWidth, Constants.TileHeight, Constants.TileXCount, Constants.TileYCount);

            playerBox = new Player(game);
            botPlayer = new BotPlayer(game);

            resourceMgr = new ResourceManager(game);
            hud = new Hud(game);

            //count++;
        }

        public override void Initialize()
        {
            playerBox.Initialize();
            world.Initialize();
            botPlayer.Initialize();

            resourceMgr.Initialize();

            SoundDJ.GetInstance(@"Content\FX\audio.xgs", @"Content\FX\wave bank.xwb", @"Content\FX\sound bank.xsb");

            hud.Initialize();
            
        }

        public override void LoadContent()
        {
            gameScreen =  game.Content.Load<Texture2D>(Constants.World_BackgroundPath);

            graphics.PreferredBackBufferWidth = Constants.WindowWidth;
            graphics.PreferredBackBufferHeight = Constants.WindowHeight;
            graphics.ApplyChanges();

            playerBox.LoadContent();
            botPlayer.LoadContent();
            resourceMgr.LoadContent();

            world.LoadContent();
            
            Initialized = true;
        }

        #endregion

        public override UpdateAction Update(Microsoft.Xna.Framework.GameTime gameTime)
        {
            SoundDJ.GetInstance().Update();
            if (input.KeyJustPressed(Keys.Escape))
            {
                playGameController.SetState(playGameController.GetGamePauseState());
                return UpdateAction.None;
            }
            if (!isGameOver())
            {
                playerBox.Update(gameTime);
                botPlayer.Update(gameTime);

                resourceMgr.Update(gameTime);
                world.Update(gameTime);
                hud.Update(gameTime);
            }

            return UpdateAction.None;
        }

        private bool isGameOver()
        {
            if (playerBox.Victory == VictoryState.Victorious || playerBox.Victory == VictoryState.Defeated)
            {
                playGameController.SetState(playGameController.GetGameCompletedState(playerBox.Victory));
                return true;
            }

            return false;
        }

        public override void Draw(Microsoft.Xna.Framework.GameTime gameTime)
        {
            spriteBatch.Begin();
            //spriteBatch.Draw(gameScreen, Vector2.Zero, Color.White);
            //spriteBatch.DrawString(font, count.ToString(), new Vector2(300, 50), Color.Red);
            world.Draw(gameTime);

            playerBox.Draw(gameTime);
            botPlayer.Draw(gameTime);
            resourceMgr.Draw(gameTime);
            
            spriteBatch.End();

            hud.Draw(gameTime);
        }
    }
}
