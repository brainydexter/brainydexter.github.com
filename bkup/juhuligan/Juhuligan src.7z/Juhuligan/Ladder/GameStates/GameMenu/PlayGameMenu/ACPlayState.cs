﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ladder.GameStates.GameMenu.PlayGameMenu
{
    public abstract class ACPlayState : ACMenuState
    {
        public bool initialized = false;

        public virtual bool Initialized
        {
            get { return initialized; }
            set { initialized = value; }
        }

        protected PlayGameMenuItem playGameController;

        public ACPlayState(PlayGameMenuItem playGameController)
            : base("", Microsoft.Xna.Framework.Vector2.Zero,playGameController.mainMenuMgr.gameStateMgr)
        {
            this.playGameController = playGameController;
        }

    }
}
