﻿#region Using Statements

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

using Library.InputNS;
using Ladder.WorldNS;
using Ladder.GameObjects;

using Ladder.NPC;
using Ladder.PC;
using Ladder.Resources;

using Ladder.UI;
#endregion

namespace Ladder.GameStates.GameMenu.PlayGameMenu
{
    public class GamePauseState : ACPlayState
    {
        //this background size should be >= size of the mainMenu background
        Texture2D pauseScreen;

        List<ACMenuState> pauseOptionsList;
        int currentOption = 0;

        //static int count = 0;

        public GamePauseState(PlayGameMenuItem playGameController)
            : base(playGameController)
        {
            pauseOptionsList = new List<ACMenuState>();

            //count++;
        }

        public override void Initialize()
        {
            int posX = (int)(Constants.WindowWidth *0.5) - 100;
            int posY = (int)(Constants.WindowHeight * 0.5);

            pauseOptionsList.Add(new ReturnToGamePauseItem(playGameController.mainMenuMgr,"Return to Game", new Vector2(posX, posY += 50)));
            pauseOptionsList.Add(new BackMenuItem(playGameController.mainMenuMgr, "Back to Main Menu", new Vector2(posX, posY += 50)));

            foreach (ACMenuState option in pauseOptionsList)
                option.Initialize();
        }

        public override void LoadContent()
        {
            pauseScreen = playGameController.mainMenuMgr.gameStateMgr.Content.Load<Texture2D>
                ("gamepause");

            foreach (ACMenuState option in pauseOptionsList)
                option.LoadContent();

            Initialized = true;
        }



        public override UpdateAction Update(Microsoft.Xna.Framework.GameTime gameTime)
        {
            if (input.KeyJustPressed(Keys.Down))
                currentOption = (currentOption + 1) % pauseOptionsList.Count;
            else if (input.KeyJustPressed(Keys.Up))
            {
                if (currentOption - 1 < 0)
                    currentOption = pauseOptionsList.Count - 1;
                else
                    currentOption--;
            }
            else if (input.KeyJustPressed(Keys.Enter))
            {
                if (pauseOptionsList[currentOption].GetType() == typeof(BackMenuItem))
                {
                    playGameController.exitGamePlayState = true; //goes back to main menu
                    return UpdateAction.None;
                }
                else if (pauseOptionsList[currentOption].GetType() == typeof(ReturnToGamePauseItem))
                {
                    playGameController.SetState(playGameController.GetGamePlayState()); //return to game
                    return UpdateAction.None;
                }
                
                pauseOptionsList[currentOption].Update(gameTime);
            }
            else if (input.KeyJustPressed(Keys.Escape))
            {
                playGameController.SetState(playGameController.GetGamePlayState()); //return to game
                return UpdateAction.None;
            }

            return UpdateAction.None;
        }

        public override void Draw(Microsoft.Xna.Framework.GameTime gameTime)
        {
            playGameController.mainMenuMgr.gameStateMgr.spriteBatch.Begin();
            playGameController.mainMenuMgr.gameStateMgr.spriteBatch.Draw(pauseScreen, Vector2.Zero, Color.White);
            //playGameController.mainMenuMgr.gameStateMgr.spriteBatch.DrawString(
                //playGameController.mainMenuMgr.gameStateMgr.font, count.ToString(), new Vector2(300, 500), Color.Orange);

            foreach (ACMenuState option in pauseOptionsList)
                playGameController.mainMenuMgr.gameStateMgr.spriteBatch.DrawString(
                    playGameController.mainMenuMgr.gameStateMgr.font, option.text, option.position, Color.Black);

            playGameController.mainMenuMgr.gameStateMgr.spriteBatch.DrawString(
                playGameController.mainMenuMgr.gameStateMgr.font, pauseOptionsList[currentOption].text,
                pauseOptionsList[currentOption].position, Color.Red);

            playGameController.mainMenuMgr.gameStateMgr.spriteBatch.End();
        }
    }
}
