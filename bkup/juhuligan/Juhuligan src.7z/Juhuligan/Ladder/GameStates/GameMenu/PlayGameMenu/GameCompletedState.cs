﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

namespace Ladder.GameStates.GameMenu.PlayGameMenu
{
    public class GameCompletedState : ACPlayState
    {
        VictoryState victoryState;
        Texture2D gameCompletedScreen;
        SpriteBatch spriteBatch;

        public GameCompletedState(PlayGameMenuItem playGameController, VictoryState state)
            : base(playGameController)
        {
            this.victoryState = state;

            spriteBatch = playGameController.mainMenuMgr.gameStateMgr.spriteBatch;
        }

        public override void Initialize()
        {
            
        }

        public override void LoadContent()
        {
            switch (victoryState)
            {
                case VictoryState.Victorious:
                    gameCompletedScreen = playGameController.mainMenuMgr.gameStateMgr.Content.Load<Texture2D>
                        ("winScreen");
                    break;

                case VictoryState.Defeated:
                    gameCompletedScreen = playGameController.mainMenuMgr.gameStateMgr.Content.Load<Texture2D>
                        ("looseScreen");
                    break;
            }
        }

        public override UpdateAction Update(GameTime gameTime)
        {
            if (input.KeyJustPressed(Keys.Enter) || input.KeyJustPressed(Keys.Escape))
                playGameController.exitGamePlayState = true;

            return UpdateAction.None;
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            spriteBatch.Draw(gameCompletedScreen, Vector2.Zero, Color.White);
            spriteBatch.End();
        }
    }
}
