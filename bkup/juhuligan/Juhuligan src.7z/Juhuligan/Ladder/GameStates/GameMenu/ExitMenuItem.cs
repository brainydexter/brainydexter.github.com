﻿using System;
using Microsoft.Xna.Framework;


namespace Ladder.GameStates.GameMenu
{
    class ExitMenuItem : ACMenuState
    {
        GameMainMenuState mainMenuMgr;

        public ExitMenuItem(GameMainMenuState mainMenuMgr, string text, Vector2 posn)
            : base(text, posn, mainMenuMgr.gameStateMgr)
        {
            this.mainMenuMgr = mainMenuMgr;
        }

        public override void Initialize()
        {
        }

        public override void LoadContent()
        {
        }

        public override UpdateAction Update(GameTime gameTime)
        {
            mainMenuMgr.exitGame = true;

            return UpdateAction.Remove;
        }

        public override void Draw(GameTime gameTime)
        {
        }

        public bool isInitialized()
        {
            return true;
        }

    }
}
