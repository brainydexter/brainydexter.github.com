﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

using Library.InputNS;

namespace Ladder.GameStates.GameMenu
{
    class OptionsMenuItem : ACMenuState
    {
        GameMainMenuState mainMenuMgr;

        List<ACMenuState> optionsList;
        int currentOption = 0;

        public OptionsMenuItem(GameMainMenuState mainMenuMgr, string text, Vector2 pos)
            : base(text, pos, mainMenuMgr.gameStateMgr)
        {
            this.mainMenuMgr = mainMenuMgr;

            optionsList = new List<ACMenuState>();
        }

        public override void Initialize()
        {
            optionsList.Add(new AudioOptionItem(mainMenuMgr, "Audio", new Vector2(400, 0)));
            //optionsList.Add(new VideoOptionItem(mainMenuMgr, "Video", new Vector2(400, 100)));
            //optionsList.Add(new GamePlayOptionItem(mainMenuMgr, "GamePlay", new Vector2(400, 200)));
            optionsList.Add(new BackMenuItem(mainMenuMgr, "Back", new Vector2(400, 200)));
        }

        public override void LoadContent()
        {
        }

        public override UpdateAction Update(GameTime gameTime)
        {

            if (input.KeyJustPressed(Keys.Down))
                currentOption = (currentOption + 1) % optionsList.Count;
            else if (input.KeyJustPressed(Keys.Enter))
            {
                if (optionsList[currentOption].text == "Back")
                    return UpdateAction.Remove;

                mainMenuMgr.mainMenuStack.Push(optionsList[currentOption]);
            }
            return UpdateAction.None;
        }

        public override void Draw(GameTime gameTime)
        {
            mainMenuMgr.gameStateMgr.spriteBatch.Begin();
            
            foreach (ACMenuState optionItem in optionsList)
                mainMenuMgr.gameStateMgr.spriteBatch.DrawString(mainMenuMgr.gameStateMgr.font, 
                                                    optionItem.text,optionItem.position, Color.Black);

            mainMenuMgr.gameStateMgr.spriteBatch.DrawString(mainMenuMgr.gameStateMgr.font,
                                optionsList[currentOption].text,
                                optionsList[currentOption].position, Color.Red);
            mainMenuMgr.gameStateMgr.spriteBatch.End();
        }

        public bool isInitialized()
        {
            return true;
        }
    }
}
