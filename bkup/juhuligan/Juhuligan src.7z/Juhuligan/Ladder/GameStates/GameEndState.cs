﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Ladder.GameStates
{
    public class GameEndState : IGameState
    {
        Texture2D menuSheet;

        public bool initialized = false;
        GameManager gameStateMgr;

        public GameEndState(GameManager menuMgr)
        {
            gameStateMgr = menuMgr;
        }

        #region IGameState Members

        public void Initialize()
        {
        }

        public void LoadContent()
        {
            menuSheet = gameStateMgr.Content.Load<Texture2D>("end");

            initialized = true;
        }

        public UpdateAction Update(GameTime gameTime)
        {
            if(gameStateMgr.input.KeyJustPressed(Keys.Escape))
                gameStateMgr.Exit();

            return UpdateAction.None;
        }

        public void Draw(GameTime gameTime)
        {
            gameStateMgr.spriteBatch.Begin();

            gameStateMgr.spriteBatch.Draw(menuSheet, Vector2.Zero, Color.White);

            gameStateMgr.spriteBatch.End();
        }

        public bool isInitialized()
        {
            return initialized;
        }

        #endregion
    }
}
