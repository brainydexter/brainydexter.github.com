﻿using Microsoft.Xna.Framework;

namespace Ladder.GameStates
{
    public interface IGameState
    {
        void Initialize();
        void LoadContent();
        UpdateAction Update(GameTime gameTime);
        void Draw(GameTime gameTime);

        bool isInitialized();
    }
}
