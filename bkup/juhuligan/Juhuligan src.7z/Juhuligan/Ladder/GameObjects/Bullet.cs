﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;

using Library.SpriteSheetNS;
using Ladder.GameStates.GameMenu.PlayGameMenu;

namespace Ladder.GameObjects
{
    /// <summary>
    /// 1. Fire(startPos, tgtPos)
    /// 2. Each frame call update
    /// </summary>
    class Bullet:GameObject
    {
        float rotation;

        bool active;

        Vector2 initialPosn;

        Vector2 tgtPosition;
        Vector2 lifeTime;

        int damage;

        TrajectoryType typeTrajectory;

        int signY = -1;
        int signX = 1;
        Direction direction;

        public Direction Directin
        {
            get { return direction; }
            set { direction = value; }
        }

        public bool Active
        {
            get { return active; }
            set
            {
                if (false == value)
                {
                    worldPosition = new Vector2(-1, -1);
                    velocity = Vector2.Zero;
                    signY = -1;
                    signX = 1;
                }

                active = value;
            }
        }

        public int Damage
        {
            get { return damage; }
        }

        public Bullet(Game game,SpriteSheet sprite, int tileNum)
            : base(game)
        {
            spriteSheet = sprite;
            tileNumber = tileNum;

            damage = 10;

            Active = false;

            typeTrajectory = TrajectoryType.None;
        }

        public UpdateAction UpdateWeaponBullet(GameTime gameTime)
        {
            if (typeTrajectory == TrajectoryType.Straight)
            {
                if (velocity == Vector2.Zero)
                    velocity = TrajectoryStraight(worldPosition, tgtPosition);

                worldPosition += velocity;
                LifeTime_OffScreen();
                rotation = (float)Math.Atan2(velocity.Y, velocity.X);

                if (Active == false)
                    return UpdateAction.Remove;
            }
            return UpdateAction.None;
        }

        public override void Update(GameTime gameTime)
        {
            if (Active)
            {
                switch (typeTrajectory)
                {
                    case TrajectoryType.Straight:
                        if(velocity == Vector2.Zero)
                            velocity = TrajectoryStraight(worldPosition, tgtPosition);

                        worldPosition += velocity;
                        LifeTime_OffScreen();
                        break;

                    case TrajectoryType.LeapFrog:
                        velocity = TrajectoryLeapFrog();                        
                        worldPosition += (velocity * 1.0f);
                        worldPosition.Y += 0.05f;
                        LifeTime_OffScreen();
                        break;

                    case TrajectoryType.Quartere:
                        velocity = TrajectoryQuartere();
                        worldPosition += velocity;
                        LifeTime_OffScreen();
                        break;

                    case TrajectoryType.Boomerang:
                        velocity = TrajectoryBoomerang();
                        worldPosition += velocity;
                       // LifeTime_OffScreen();
                        break;

                }
                //velocity = Trajectory(worldPosition, tgtPosition);
                //worldPosition += velocity;

                rotation = (float)Math.Atan2(velocity.Y, velocity.X);

                
            }
        }

        private Vector2 TrajectoryBoomerang()
        {
            if (velocity.X > 0.2f )
            {
                signX = -1;
                signY = 1;
            }
            else if (velocity.X < -0.2f)
            {
                signX = 1;
                signY = -1;
            }

            if (velocity.Y < -0.1f && signX == 1)
                signY = 1;
            else if (velocity.Y > 0.1f && signX == -1)
                signY = -1;
            
            velocity.X += (signX * 0.002f); 
            velocity.Y += (signY * 0.002f);

            double x = Math.Round((double)velocity.X, 4);
            if (x - 0.002 == 0 && signX == -1)
            {
                signY = 1;
            }
            else if (x + 0.002 == 0 && signX == 1)
            {
                Active = false;
            }
            
            return velocity;
        }

        private Vector2 TrajectoryQuartere()
        {                      
            if (tgtPosition.X > initialPosn.X)
            {
                if (0 == velocity.X)
                    velocity.X = 0.2f;
                
                velocity.X += -0.005f;
            }
            else if (tgtPosition.X < initialPosn.X)
            {
                if (0 == velocity.X)
                    velocity.X = -0.2f;

                velocity.X += 0.005f;
            }
            
            velocity.Y += 0.005f;

            return velocity;
        }

        private void LifeTime_OffScreen()
        {
            lifeTime.X = Math.Abs(worldPosition.X - initialPosn.X);
            lifeTime.Y = Math.Abs(worldPosition.Y - initialPosn.Y);

            if (lifeTime.X > Constants.viewPortHeight || lifeTime.Y > Constants.viewPortWidth / 2)
                Active = false;
        }

        /// <summary>
        /// Weapon calls this method to activate this bullet and fires it in the target position direction.
        /// </summary>
        /// <param name="muzzlePosn">Position of the muzzle</param>
        /// <param name="tgtPosn">Target position</param>
        public void Fire(Vector2 muzzlePosn,Vector2 tgtPosn, TrajectoryType typeTrajctry)
        {
            Active = true;
            initialPosn = muzzlePosn;
            
            worldPosition = muzzlePosn;
            tgtPosition = tgtPosn;

            typeTrajectory = typeTrajctry;
            //velocity = Trajectory(worldPosition, tgtPosn);
            //velocity = Projectile.ProcessTrajectory(
            //                                        Projectile.projectileDictionary[TrajectoryType.Straight], 
            //                                        muzzlePosn, tgtPosn);

        }
        
        /// <summary>
        /// Used to find the current velocity needed to go from givenPosn to tgtPosn
        /// </summary>
        /// <param name="worldPosition"></param>
        /// <param name="tgtPosn"></param>
        /// <returns>displacement needed</returns>
        private Vector2 TrajectoryStraight(Vector2 givenPosition, Vector2 tgtPosn)
        {
            Vector2 vel = tgtPosn - givenPosition;

            if (vel.X < 0.5f && vel.X > -0.5f && vel.Y < 0.5f && vel.Y > -0.5f )
            {
                Active = false;
                return Vector2.Zero;
            }

            vel.Normalize();

            vel *= 0.05f;
            return vel;
        }

        private Vector2 TrajectoryLeapFrog()
        {
            if (velocity.Y > 0.4f) signY = -1;
            else if (velocity.Y < -0.4f) signY = 1;
            
            velocity.Y += (signY * 0.025f);

            if (tgtPosition.X > initialPosn.X) velocity.X = 0.1f;
            else if (tgtPosition.X < initialPosn.X) velocity.X = -0.1f;

            return velocity;
        }

        public override void Draw(GameTime gameTime)
        {
            if (Active)
            {
                //Drawing the muzzle
                Vector2 screenPosn = world.WorldToScreen(worldPosition);

                GamePlayState.SSpriteBatch.Draw(spriteSheet.SpriteSheeet,
                    new Rectangle((int)(screenPosn.X + (spriteSheet.TileWidth / 2)), (int)screenPosn.Y, spriteSheet.TileWidth, spriteSheet.TileHeight),
                    spriteSheet.getTextureRectangle(tileNumber),
                    Microsoft.Xna.Framework.Graphics.Color.White,
                    rotation,
                    new Vector2(spriteSheet.TileWidth / 2, spriteSheet.TileHeight / 2),
                    Microsoft.Xna.Framework.Graphics.SpriteEffects.None, 0f);

            }
        }
    }
}
