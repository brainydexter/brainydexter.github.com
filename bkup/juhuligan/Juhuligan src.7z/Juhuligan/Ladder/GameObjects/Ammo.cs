﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Library.SpriteBoard;
#endregion

namespace Ladder.GameObjects
{
    //This enum defines the index in the spriteSheet
    //todo: Draw bullets and give these enum that number
    enum AmmoType
    {
        Bullet = 2,
        Boomerang =4
    }

    struct AmmoDetails
    {
        int ammoDamage;
        int spriteIndex;

        public AmmoDetails(int dmg, int index)
        {
            ammoDamage = dmg;
            spriteIndex = index;
        }

        public int AmmoDamage
        {
            get { return ammoDamage; }
        }
    }

    class Ammo
    {
        #region Fields

        AmmoType ammoType;
                
        Vector2 position;
        Vector2 velocity;
        
        int lifeTime;
        int age;
        Vector2 initPos;

        int damage;

        private bool active;

        SpriteSheet parentSpriteSheet;

        static Dictionary<AmmoType, AmmoDetails> ammoLookup = new Dictionary<AmmoType, AmmoDetails>();

        private bool deflected;

        #endregion

        #region Initialization

        /// <summary>
        /// Initializes the static ammo-dmg table
        /// </summary>
        static Ammo()
        {
            AmmoDetails BulletDetails = new AmmoDetails(Constants.BulletDmg, 2);
            ammoLookup.Add(AmmoType.Bullet, BulletDetails);

            AmmoDetails BoomerangDetails = new AmmoDetails(Constants.BoomerangDmg, 4);
            ammoLookup.Add(AmmoType.Boomerang, BoomerangDetails);
        }

        public Ammo(AmmoType ammoID, Vector2 pos, SpriteSheet spriteSheet)
        {
            ammoType = ammoID;
            damage = ammoLookup[ammoID].AmmoDamage;

            position = pos;
            velocity = Vector2.Zero;

            parentSpriteSheet = spriteSheet;

            Deflected = false;

            switch (ammoID)
            {
                case AmmoType.Bullet:
                    lifeTime = Constants.viewPortWidth;
                    age = 0;
                    initPos = pos;
                    break;

                default:
                    break;
            }
            
        }

        #endregion

        #region Properties

        //to be used by enemies to see if the ammo has been deflected by player or not
        public bool Deflected
        {
            get { return deflected; }
            set { deflected = value; }
        }

        public bool Active
        {
            get { return active; }
            set 
            {
                if (false == value)
                {
                    position = initPos;
                }
                else
                {
                    Deflected = false;
                }
                active = value; }
        }

        public float VelocityX
        {
            get { return velocity.X; }
            set { velocity.X = value; }
        }

        public float VelocityY
        {
            get { return velocity.Y; }
            set { velocity.Y = value; }
        }
        
        public Vector2 Velocity
        {
            get { return velocity; }
            set { velocity = value; }
        }

        public float PositionX
        {
            get { return position.X; }
            set { position.X = value; }
        }

        public float PositionY
        {
            get { return position.Y; }
            set { position.Y = value; }
        }

        public int Damage
        {
            get { return damage; }
        }

        /// <summary>
        /// Bounding box rectangle for the given ammo
        /// (todo) different BB for different types of ammo
        /// </summary>
        public Rectangle BoundingBox
        {
            get
            {
                return new Rectangle(
                    (int)position.X,
                    (int)position.Y,
                    Constants.TileWidth,
                    Constants.TileHeight
                    );
            }
        }
        
        private int PositionWorldY
        {
            get { return (int)(Math.Floor(PositionY / Constants.TileHeight)); }
        }

        #endregion

        #region Update

        public void Update()
        {
            //position -= velocity;
        }

        #endregion

        #region Draw

        public void Draw()
        {
            //GamePlayState.SSpriteBatch.Draw(ammoSprite, position, Color.White);
        }

        #endregion

        #region Helper Methods

        private int PositionWorldX(float pos)
        {
            return (int)(Math.Floor(pos / Constants.TileWidth));
        }
                
        /// <summary>
        /// Destroys the ammo based of some condition
        /// </summary>
        /// <returns>false if ammo is not destroyed</returns>
        public bool Dead()
        {
            switch (ammoType)
            {
                case AmmoType.Bullet:
                    {
                        age = Math.Abs(PositionWorldX(position.X) - PositionWorldX(initPos.X));
                        if(age == lifeTime) 
                        {
                            Active = false;
                            return true;
                        }
                        else if (PositionX <= 0)
                        {
                            Active = false;
                            return true;
                        }
                        return false;
                    }
                    
                default:
                    break;
            }
            return false;
        }

        #endregion
    }
}
