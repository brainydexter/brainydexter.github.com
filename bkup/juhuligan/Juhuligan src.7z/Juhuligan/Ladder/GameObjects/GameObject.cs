﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Library.SpriteSheetNS;

using Ladder;
using Ladder.WorldNS;

namespace Ladder.GameObjects
{
    class GameObject : DrawableGameComponent
    {
        #region Fields

        protected Vector2 worldPosition;
        protected Vector2 velocity;

        protected SpriteSheet spriteSheet;

        protected Vector2 size;

        protected int tileNumber;

        protected static IWorld world;

        #endregion

        #region Properties

        public Rectangle BoundingBox
        {
            get
            {
                return new Rectangle(
                    (int)(worldPosition.X * spriteSheet.TileWidth),
                    (int)(worldPosition.Y * spriteSheet.TileHeight),
                    (int)(size.X * spriteSheet.TileWidth),
                    (int)(size.Y * spriteSheet.TileHeight)
                    );
            }
        }

        public Vector2 WorldPosition
        {
            get { return worldPosition; }
        }

        #endregion

        #region Initialization

        public GameObject(Game game, String sheetName, int tileWidth, int tileHeight, int spriteTileXCount, int spriteTileYCount)
            : this(game)
        {            
            spriteSheet = new SpriteSheet(Game.Content, sheetName, tileWidth, tileHeight, spriteTileXCount, spriteTileYCount);
        }

        /// <summary>
        /// Initializes size, worldPosition and velocity.
        /// Note: Initialize the spritesheet when this constructor is invoked.
        /// Override tileNumber
        /// </summary>
        /// <param name="game"></param>
        public GameObject(Game game)
            : base(game)
        {
            size = new Vector2(1, 1);

            worldPosition = Vector2.Zero;
            velocity = Vector2.Zero;
        }

        /// <summary>
        /// Pulls up the world into static member world
        /// </summary>
        public override void Initialize()
        {
            world = Game.Services.GetService(typeof(IWorld)) as IWorld;
        }

        public void LoadContent()
        {
            spriteSheet.Load();
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Move the object based off of his current velocity.
        /// Object will be obstructed by any walls
        /// </summary>
        /// <returns>Flags representing the directions in which player had a collision</returns>
        protected virtual Direction Move()
        {
            Direction hitDirection = Direction.None;
            Vector2 displacement = velocity;

            
            if (displacement.X > 0f)
            {
                Vector2 collPos = new Vector2(worldPosition.X + size.X, worldPosition.Y);
                Vector2 collSize = new Vector2(displacement.X, size.Y);

                float newPosX;

                if (Collide(collPos, collSize, Direction.Right, out newPosX))
                {
                    hitDirection |= Direction.Right;
                    velocity.X = 0.0f;
                }

                worldPosition.X = newPosX - size.X;
            }
            else if (displacement.X < 0f)
            {
                Vector2 collPos = new Vector2(worldPosition.X + displacement.X, worldPosition.Y);
                Vector2 collSize = new Vector2(-displacement.X, size.Y);

                float newPosX;

                if (Collide(collPos, collSize, Direction.Left, out newPosX))
                {
                    hitDirection |= Direction.Left;
                    velocity.X = 0.0f;
                }

                worldPosition.X = newPosX;
            }

            if (displacement.Y > 0f)
            {
                Vector2 collPos = new Vector2(worldPosition.X, worldPosition.Y + size.Y);
                Vector2 collSize = new Vector2(size.X, displacement.Y);

                float newPosY;

                if (Collide(collPos, collSize, Direction.Down, out newPosY))
                {
                    hitDirection |= Direction.Down;
                    velocity.Y = 0.0f;
                }

                worldPosition.Y = newPosY - size.Y;
            }
            else if (displacement.Y < 0f)
            {
                Vector2 collPos = new Vector2(worldPosition.X, worldPosition.Y + displacement.Y);
                Vector2 collSize = new Vector2(size.X, -displacement.Y);

                float newPosY;

                if (Collide(collPos, collSize, Direction.Up, out newPosY))
                {
                    hitDirection |= Direction.Up;
                    velocity.Y = 0.0f;
                }

                worldPosition.Y = newPosY;
            }

            if (worldPosition.X < 0)
            {
                worldPosition.X -= displacement.X;
                hitDirection |= Direction.Left;
            }
            else if (worldPosition.X + size.X > Constants.mapWidth)
            {
                worldPosition.X -= displacement.X;
                hitDirection |= Direction.Right;
            }

            return hitDirection;
        }

        
        private bool Collide(Vector2 collPos, Vector2 collSize, Direction direction, out float newpos)
        {
            // Find the bounding box for the given area as whole tiles.
            float maxxf = (collPos.X + collSize.X);
            float maxyf = (collPos.Y + collSize.Y);
            int minx = (int)collPos.X;
            int miny = (int)collPos.Y;
            int maxx = (int)maxxf;
            int maxy = (int)maxyf;

            if (Constants.IsInt(maxxf)) maxx--;
            if (Constants.IsInt(maxyf)) maxy--;

            if (direction == Direction.Right)
            {
                // We are travelling right, we will reach the right edge
                // of the given area if we don't hit anything.
                newpos = collPos.X + collSize.X;

                // Scan through the tiles we're travelling through from left to right.
                for (int x = minx; x <= maxx; x++)
                {
                    for (int y = miny; y <= maxy; y++)
                    {
                        if (world.SolidSquare(x, y))
                        {
                            // If we find a wall then return the position of the left
                            // hand side of it.
                            newpos = (float)x;
                            return true;
                        }
                    }
                }
                return false;
            }

            if (direction == Direction.Left)
            {
                // We are travelling left, we will reach the left edge
                // of the given area if we don't hit anything.
                newpos = collPos.X;

                // Scan through the tiles we're travelling through from right to left.
                for (int x = maxx; x >= minx; x--)
                {
                    for (int y = miny; y <= maxy; y++)
                    {
                        if (world.SolidSquare(x, y))
                        {
                            // If we find a wall then return the position of the right
                            // hand side of it.
                            newpos = (float)(x + 1);
                            return true;
                        }
                    }
                }
                return false;
            }

            if (direction == Direction.Down)
            {
                // We are travelling down, we will reach the bottom edge
                // of the given area if we don't hit anything.
                newpos = collPos.Y + collSize.Y;

                // Scan through the tiles we're travelling through from top to bottom.
                for (int y = miny; y <= maxy; y++)
                {
                    for (int x = minx; x <= maxx; x++)
                    {
                        if (world.SolidSquare(x, y))
                        {
                            // If we find a wall then return the position of the top of it.
                            newpos = (float)y;
                            return true;
                        }
                    }
                }
                return false;
            }

            if (direction == Direction.Up)
            {
                // We are travelling up, we will reach the top edge
                // of the given area if we don't hit anything.
                newpos = collPos.Y;

                // Scan through the tiles we're travelling through from bottom to top.
                for (int y = maxy; y >= miny; y--)
                {
                    for (int x = minx; x <= maxx; x++)
                    {
                        if (world.SolidSquare(x, y))
                        {
                            // If we find a wall then return the position of the bottom of it.
                            newpos = (float)(y + 1);
                            return true;
                        }
                    }
                }
                return false;
            }

            // Should shouldn't ever reach here but the compiler moans if we don't do this.
            newpos = 0.0f;
            return true;
        }

        #endregion

        #region Draw

        /// <summary>
        /// Draws the object's sprite at worldPosition. 
        /// Override this method, if:
        /// - using different spritesheet at different times of the game-play.
        /// </summary>
        /// <param name="gameTime"></param>
        public override void Draw(GameTime gameTime)
        {
            world.DrawOnScreen(tileNumber, worldPosition, spriteSheet);
        }

        #endregion
    }
}
