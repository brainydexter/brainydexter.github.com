#region Using Statements

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

using Library.InputNS;
using Ladder.WorldNS;
using Ladder.GameObjects;

using Ladder.NPC;
using Ladder.PC;
using Ladder.Resources;

using Ladder.UI;
using Library.AudioNS;
#endregion


namespace Ladder
{
    public enum VictoryState
    {
        Victorious,
        Defeated,
        Playing
    }

    enum GameState
    {
        Idle,
        Running,
        Paused,
        Completed,
        Intro
    }
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        #region Fields

        GraphicsDeviceManager graphics;
        static SpriteBatch spriteBatch;

        IMouseHandler input;

        Player playerBox;
        BotPlayer botPlayer;
        ResourceManager resourceMgr;
        Hud hud;

        World world;

        GameState gameState;
        private static SpriteFont spriteFont;

        Texture2D logo;

        #endregion

        #region Initialization

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            input = new MouseHandler(this);

            //world should be made before player
            world = new World(this, Constants.LevelPath, Constants.TileWidth, Constants.TileHeight, Constants.TileXCount, Constants.TileYCount);

            playerBox = new Player(this);
            botPlayer = new BotPlayer(this);

            resourceMgr = new ResourceManager(this);
            hud = new Hud(this);
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            playerBox.Initialize();
            botPlayer.Initialize();

            resourceMgr.Initialize();

            gameState = GameState.Running;

            world.Initialize();

            SoundDJ.GetInstance("Content/FX/audio.xgs", "Content/FX/wave_bank.xwb", "Content/FX/sound_bank.xwb");
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            spriteFont = Content.Load<SpriteFont>(Constants.FontPath);

            // TODO: use this.Content to load your game content here
            graphics.PreferredBackBufferWidth = Constants.WindowWidth;
            graphics.PreferredBackBufferHeight = Constants.WindowHeight;
            graphics.ApplyChanges();

            playerBox.LoadContent();
            botPlayer.LoadContent();
            resourceMgr.LoadContent();

            world.LoadContent();

            logo = Content.Load<Texture2D>(Constants.Game_LogoPath);
        }

        #endregion

        #region Properties

        public static SpriteBatch SSpriteBatch
        {
            get { return spriteBatch; }
        }

        public static SpriteFont SSpriteFont
        {
            get
            { return spriteFont; }
        }

        #endregion

        #region Update

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // TODO: Add your update logic here
            base.Update(gameTime);

            UpdateInput();
            
            if(gameState == GameState.Running && !isGameOver())
            {
                playerBox.Update(gameTime);
                botPlayer.Update(gameTime);

                resourceMgr.Update(gameTime);
                world.Update(gameTime);
            }

           
        }        

        #endregion

        #region Draw

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.White);

            // TODO: Add your drawing code here

            

            if (gameState == GameState.Intro)
            {
                #region Intro
                spriteBatch.Begin();

                spriteBatch.Draw(logo, new Rectangle(0, 0, Constants.WindowWidth, Constants.WindowHeight), Color.White);

                spriteBatch.DrawString(spriteFont, "Lines & Curves",
                        new Vector2((Constants.WindowWidth / 2) - 37, (Constants.WindowHeight / 4)),
                        Color.Gray);

                spriteBatch.DrawString(spriteFont, "ENTER to set Straight those Curves",
                                        new Vector2((Constants.WindowWidth / 2) - 150,  (Constants.WindowHeight - 180)),
                                        Color.Goldenrod);
                
                spriteBatch.DrawString(spriteFont, "Psst.. Reach till the end, and kill their Fat Boss. They will follow his league.",
                                                        new Vector2( 50, (Constants.WindowHeight - 50)),
                                                        Color.Olive);
                spriteBatch.End();

                #endregion
            }
            else
            {
                #region Game Over Draw
                if (isGameOver())
                {
                    string message = "";
                    switch (playerBox.Victory)
                    {
                        case VictoryState.Victorious:
                            message = "Thanks to you! The world is no more rOund";
                            break;

                        case VictoryState.Defeated:
                            message = "Your actions are of no consequence.\n         You were unable to bring about any changes to this wOrld";
                            break;
                    }

                    spriteBatch.Begin();

                    SSpriteBatch.DrawString(SSpriteFont, message,
                                            new Vector2((Constants.WindowWidth / 2) - 180, (Constants.WindowHeight / 2) - 60), Color.Black);
                    SSpriteBatch.DrawString(
                                            SSpriteFont, "Game Over",
                                            new Vector2((Constants.WindowWidth / 2) - 60, Constants.WindowHeight / 2),
                                            Color.Red);
                    SSpriteBatch.DrawString(
                                            SSpriteFont, "Press Escape to flee away",
                                            new Vector2((Constants.WindowWidth / 2) - 100, (Constants.WindowHeight / 2) + 40),
                                            Color.White);

                    spriteBatch.End();

                #endregion
                }
                else
                {
                    #region Game Draw
                    spriteBatch.Begin();
                    
                    world.Draw(gameTime);

                    playerBox.Draw(gameTime);
                    botPlayer.Draw(gameTime);
                    resourceMgr.Draw(gameTime);

                    spriteBatch.End();

                    spriteBatch.Begin(SpriteBlendMode.AlphaBlend);


                    spriteBatch.End();

                    #endregion

                }
            }
            base.Draw(gameTime);
        }

        #endregion

        #region Helper Methods

        private void UpdateInput()
        {
            if (gameState == GameState.Intro)
            {
                if (input.KeyJustPressed(Keys.Enter))
                    gameState = GameState.Running;
            }
            if (gameState == GameState.Completed)
            {
                if (input.KeyJustPressed(Keys.Escape))
                {
                    this.Exit();
                }
            }
            if (input.KeyJustPressed(Keys.I))
                Constants.Debug = !Constants.Debug;
            else if (input.KeyJustPressed(Keys.P))
            {
                if (gameState == GameState.Running)
                    gameState = GameState.Idle;
                else if (gameState == GameState.Idle)
                    gameState = GameState.Running;
            }
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// game is over if:
        /// player run out of lives
        /// player defeats the boss monster
        /// </summary>
        /// <returns>True if player wins/looses</returns>
        private bool isGameOver()
        {
            if( playerBox.Victory == VictoryState.Victorious ||
                    playerBox.Victory == VictoryState.Defeated ) 
            {
                gameState = GameState.Completed;
                return true;
            }
            return false;
        }

        #endregion
    }
}
