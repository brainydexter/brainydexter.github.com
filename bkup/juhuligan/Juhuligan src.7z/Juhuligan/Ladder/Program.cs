using System;

namespace Ladder
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            using (GameManager game = new GameManager()) //= new Game1())
            {
                game.Run();
            }
        }
    }
}

