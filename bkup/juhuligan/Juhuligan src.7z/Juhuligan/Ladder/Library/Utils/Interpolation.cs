﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace Library.UtilsNS
{
    class Interpolation
    {
        public static List<Vector2> Quadratic(Vector2 p0, Vector2 p1, Vector2 p2)
        {
            List<Vector2> path = new List<Vector2>();

            float dt = 0;
            float step = (p0 - p1).Length();
            step = 1 / step;

            while (dt <= 1f)
            {
                Vector2 pos = ((1 - dt) * (1 - dt) * p0) + (2 * (1 - dt) * dt * p1) + (dt * dt * p2);
                path.Add(pos);

                dt += step;
            }

            return path;
        }

        public static List<Vector2> TangentLine(Vector2 p0, Vector2 p1, Vector2 where)
        {
            List<Vector2> side = new List<Vector2>();

            Vector3 tan1 = Vector3.Cross(new Vector3(p1 - p0, 0), new Vector3(0, 0, 1f));

            Vector2 tan = Vector2.Zero;
            tan.X = tan1.X;
            tan.Y = tan1.Y;

            tan.Normalize();

            for (int i = 0; i < 20; i++)
            {
                side.Add(where + i * tan);
                side.Add(where - i * tan);
            }

            return side;
        }

        public static List<Vector2> Linear(Vector2 p0, Vector2 p1)
        {
            List<Vector2> side = new List<Vector2>();

            float dt = 0;
            float step = (p0 - p1).Length();
            step = 1 / step;

            while (dt <= 1f)
            {
                Vector2 pos = p0 + dt * (p1 - p0);
                side.Add(pos);

                dt += step;
            }

            return side;
        }
    }
}
