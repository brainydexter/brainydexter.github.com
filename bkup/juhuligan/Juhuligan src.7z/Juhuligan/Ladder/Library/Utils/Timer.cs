﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Library.UtilsNS
{
    /// <summary>
    /// Draws the time in SECONDS at the specified position. It can be in either of the following modes:
    /// 1. Countdown updates in the following directions:
    ///  - forward direction (0,1,2,..count)
    ///  - reverse direction (count, count -1, .. 0)
    /// 2. Timer can operate in:
    ///  - exhaustive mode ie. once count or 0 has been reached, timer stops and dissapears
    ///  - Restarts mode from the beginnning
    /// </summary>
    class Timer : DrawableGameComponent,ITimer
    {
        SpriteFont font;

        double timerCount;

        int Count;  //maximum time upto which timer needs to run

        TimerMode timerMode;
        TimerDirection timerDirection;

        bool alive;

        public bool Alive
        {
            get { return alive; }
            set
            {
                if (value == false)
                {
                    Game.Components.Remove(this);
                }
                alive = value;
            }
        }

        public Timer(Game game, int count, TimerMode mode, TimerDirection direction)
            : base(game)
        {
            Count = count;
            timerCount = 0;

            timerMode = mode;
            timerDirection = direction;

            //game.Components.Add(this);

            Alive = true;

            LoadContent();
        }

        protected override void LoadContent()
        {
            font = Game.Content.Load<SpriteFont>("Library/Fonts/LibFont");
        }

        public override void Update(GameTime gameTime)
        {
            timerCount += gameTime.ElapsedRealTime.TotalMilliseconds;

            if (timerCount > ((Count+1) * 1000))
            {
                if (TimerMode.Exhaust == timerMode)
                    Alive = false;
                else
                    timerCount = 0;
            }
        }

        public void Draw(GameTime gameTime, Vector2 position, SpriteBatch spriteBatch)
        {
            int timer = (int)(timerCount / 1000.0);

            if (TimerDirection.Reverse == timerDirection)
                timer = Count - timer;
            
            spriteBatch.DrawString(font, timer.ToString(), position, Color.Black);
        }

        
    }

    enum TimerMode
    {
        Exhaust,
        Restart
    }

    enum TimerDirection
    {
        Forward,
        Reverse
    }
}
