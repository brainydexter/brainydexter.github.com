#region using statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
#endregion

namespace Library.SpriteSheetNS
{
    //SpriteSheet should not containt any alpha layer tile in 1st row

    //Remove Redundant Fields
    //Texture String a variable
    //Amend Load with texture string

    /// <summary>
    /// Steps to use:
    /// 1. Call constructor from the constructor of the calling class (also requires ContentManager i.e. Game.Content)
    /// 2. Call Load() from the CallingClass.LoadContent()
    /// 3. Use getTextureRectangle(index) to fetch the rectangle. (Index is 0 based)
    /// </summary>
    public class SpriteSheet
    {
        #region Fields

        private Texture2D spriteSheet;
        private string spriteName;

        private int tileWidth;      //individual width of 1 single tile
        private int tileHeight;

        int TileXOffset { get; set; }
        int TileYOffset { get; set; }

        private int tileSetXcount;
        private int tileSetYcount;

        private Rectangle specifiedTileRectangle;   //this is for efficiency puposes. 

        private ContentManager content;
        //For all lookups of the spritesheet, this rectangle will contain the coordinates on the spritesheet.
        //There should be no property for this, since it should only be accessed via getTextureRectangle(index)
        #endregion

        #region Properties

        public Texture2D SpriteSheeet
        {
            get
            {
                return spriteSheet;
            }
        }

        public int TileWidth
        {
            get
            {
                return tileWidth;
            }
        }

        public int TileHeight
        {
            get
            {
                return tileHeight;
            }
        }

        public string SpritePath
        {
            get { return spriteName; }
        }

        public int TileXCount
        {
            get
            {
                return tileSetXcount;
            }
        }

        public int TileYCount
        {
            get
            {
                return tileSetYcount;
            }
        }

        #endregion

        #region Initilization

        public SpriteSheet(ContentManager l_content, string sheetName, int tileWdth, int tileHight, int tileXCount, int tileYCount)
        {
            content = l_content;
            spriteName = sheetName;

            tileWidth = tileWdth;
            tileHeight = tileHight;

            tileSetXcount = tileXCount;     //maybe pass them through the constructor
            tileSetYcount = tileYCount;

            //TileXOffset = TileYOffset = 3;

            specifiedTileRectangle = new Rectangle(0, 0, tileWidth, tileHeight); //initialise SpecifiedRectangle here so that it can be used later.
        }

        public SpriteSheet(ContentManager l_content, string sheetName, int tileWdth, int tileHight, int xOffset, int yOffset, int tileXCount, int tileYCount)
            : this(l_content, sheetName, tileWdth, tileHight, tileXCount, tileYCount)
        {
            TileXOffset = xOffset;
            TileYOffset = yOffset;
        }


        void Initialize()
        {

        }

        //Load texture
        public void Load()
        {
            spriteSheet = content.Load<Texture2D>(spriteName);
        }

        #endregion

        #region Update




        #endregion

        #region Helper Methods

        /// <summary>
        /// Returns a rectangle of the specified tile(identified by the index)
        /// from the spritesheet containing the desired coordinates.
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public Rectangle getTextureRectangle(int index)
        {
            specifiedTileRectangle.X = (index % tileSetXcount) * (tileWidth + TileXOffset);
            specifiedTileRectangle.Y = (index / tileSetXcount) * (tileHeight + TileYOffset);

            //Widht and Height are specified in the Initialize.
            specifiedTileRectangle.X += TileXOffset != 0 ? TileXOffset - 1 : 0;
            specifiedTileRectangle.Y += TileXOffset != 0 ? TileXOffset - 1 : 0;

            return specifiedTileRectangle;
        }

        #endregion
    }
}
