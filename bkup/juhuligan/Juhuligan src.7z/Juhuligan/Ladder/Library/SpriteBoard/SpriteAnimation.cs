﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Library.SpriteSheetNS
{
    class SpriteAnimation
    {
        private Dictionary<string, AnimationInfo> animationDictionary;

        private static SpriteAnimation instance;

        /// <summary>
        /// Registers the animation with the unique name, if it doesn't already exist.
        /// </summary>
        /// <param name="name">Name of the animation.</param>
        /// <param name="sheet">Spritesheet over which the animation is to be picked up from.</param>
        /// <param name="startTile">Starting tile of the animation.</param>
        /// <param name="EndTile">Length of the animation, for e.g. length = 2 => 2 tiles would be in the animation, 
        /// the startTile and the next tile.</param>
        public void LoadAnimation(string name, SpriteSheet sheet, uint startTile, uint length) 
        {
            if (animationDictionary.ContainsKey(name))
            {
                //throw new ArgumentException(name + " already exists!");
                return;
            }

            animationDictionary.Add(name, new AnimationInfo(sheet, startTile, length));
        }

        public int PlayAnimation(string name, out bool completed) 
        {
            completed = animationDictionary[name].Completed;

            return (int)animationDictionary[name].CurrentTile;
        }

        public static SpriteAnimation GetInstance()
        {
            if (instance == null)
                instance = new SpriteAnimation();

            return instance;
        }

        private SpriteAnimation()
        {
            animationDictionary = new Dictionary<string, AnimationInfo>();
        }
    }

    class AnimationInfo
    {
        SpriteSheet spriteSheet;
        uint startTile, currentTile;
        uint length;

        int count = 0;

        public AnimationInfo(SpriteSheet sheet, uint startTile, uint length)
        {
            spriteSheet = sheet;
            this.startTile = startTile;
            this.length = length;

            this.currentTile = 0;
        }

        public uint CurrentTile
        {
            get
            {

                if (count++ >= 30)//((240/16)/length))
                {
                    count = 0;
                    currentTile = (currentTile + 1) % (length);
                }

                return startTile + currentTile;
            }
        }

        public bool Completed
        {
            get
            {
                //return currentTile == startTile + length - 1;
                if (currentTile == length - 1)
                {
                    if (count < 30)
                    {
                        return false;
                    }
                    currentTile = 0;
                    return true;
                }
                return false;
            }
        }
    }
}
