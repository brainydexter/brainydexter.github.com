﻿using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework;

namespace Library.AudioNS
{
    /// <summary>
    /// 
    /// http://msdn.microsoft.com/en-us/library/bb195055.aspx
    /// 
    /// </summary>
    class SoundDJ
    {
        private AudioEngine audioEngine;
        private WaveBank waveBank;
        private SoundBank soundBank;

        private static SoundDJ soundInstance;

        public static SoundDJ GetInstance(string audioEnginePath, string waveBankPath, string soundBankPath)
        {
            if(null == soundInstance)
                soundInstance = new SoundDJ(audioEnginePath,waveBankPath,soundBankPath);

            return soundInstance;

        }

        /// <summary>
        /// ***Use with caution. Call this only if the other overloaded GetInstance(...) has been called before, else null is returned***
        /// </summary>
        /// <returns></returns>
        public static SoundDJ GetInstance()
        {
            return soundInstance;
        }

        private SoundDJ(string audioEnginePath, string waveBankPath, string soundBankPath)
        {
            audioEngine = new AudioEngine(audioEnginePath);
            waveBank = new WaveBank(audioEngine, waveBankPath);
            soundBank = new SoundBank(audioEngine, soundBankPath);
        }

        public void Play(string cueName, bool serialPlay)
        {
            Cue cue = soundBank.GetCue(cueName);

            if (null != cue)
            {
                cue.Play();

                while (serialPlay && cue.IsPlaying) ;
                
                if(serialPlay)
                    cue.Stop(AudioStopOptions.AsAuthored);
            }
        }

        public void PlayCue(string cueName)
        {
            soundBank.PlayCue(cueName);
        }

        public void Update()
        {
            audioEngine.Update();
        }
    }
}
