﻿#region Using statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
#endregion

namespace Library.InputNS
{
    public interface IMouseHandler : IInputHandler
    {
        #region Properties

        Texture2D CursorTexture { get; set; }
        Vector2 Position { get; }

        #endregion
    }
}
