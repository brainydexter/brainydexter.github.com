#region File Description
//
// This file contains the IInputHandler interface which is used to make the InputHandler class
// a game service.
//
#endregion

using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Input;

namespace Library.InputNS
{
    public interface IInputHandler
    {
        KeyboardState KeyboardState { get; }
        GamePadState[] GamePadStates { get; }

#if !XBOX360
        MouseState MouseState { get; }
#endif

        bool KeyJustPressed(Keys key);

        bool KeyJustReleased(Keys key);

        bool KeyHeldDown(Keys key);

        bool IsKeyDown(Keys key);

        bool ControllerButtonJustPressed(int playerIndex, InputHandler.ControllerButtons button);

        bool ControllerButtonJustReleased(int playerIndex, InputHandler.ControllerButtons button);

        bool ControllerButtonHeldDown(int playerIndex, InputHandler.ControllerButtons button);

        bool ControllerTriggerJustPulled(int playerIndex, InputHandler.ControllerTrigger trigger);

        float ControllerTriggerDelta(int playerIndex, InputHandler.ControllerTrigger trigger);

        bool ControllerTriggerJustReleased(int playerIndex, InputHandler.ControllerTrigger trigger);

#if !XBOX360
        bool MouseMoved(InputHandler.MouseDirections direction);

        bool MouseButtonJustPressed(InputHandler.MouseButtons button);

        bool MouseButtonJustReleased(InputHandler.MouseButtons button);

        bool MouseButtonHeldDown(InputHandler.MouseButtons button);

        bool MouseWheelRolled(InputHandler.MouseWheelDirections wheelDirection);
#endif

    }
}
