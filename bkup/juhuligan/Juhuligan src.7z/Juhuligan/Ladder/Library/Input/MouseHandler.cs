#region using statements
using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
#endregion

namespace Library.InputNS
{
    //uses only xbox controller if it is connected, else uses the mouse
    //Clamps the cursor between Viewport width and height
    //Draw needs to be called explicitly
    public class MouseHandler : InputHandler, IMouseHandler
    {
        #region Fields

        private Vector2 position;
        private Texture2D cursorTexture;
        private int scrollSpeed;

        #endregion

        #region Properties

        public Texture2D CursorTexture
        {
            get
            {
                return cursorTexture;
            }
            set
            {
                cursorTexture = value;
            }
        }

        public Vector2 Position
        {
            get
            {
                return position;
            }
        }

        #endregion

        #region Initilization

        public MouseHandler(Game game)
            : base(game)
        {
            game.Services.AddService(typeof(IMouseHandler), this);
            game.Components.Add(this);
            position = Vector2.Zero;
            scrollSpeed = 10;
        }

        public override void  Initialize()
        {
            //cursorTexture = Game.Content.Load<Texture2D>("HUD images/resource_light");
            base.Initialize();
        }

        #endregion

        #region Update

        public override void Update(GameTime gameTime)
        {
            UpdatePointer();
            base.Update(gameTime);
        }

        #endregion

        #region Draw

        public void Draw(GameTime gameTime,SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(cursorTexture, position, Color.White);
        }

        #endregion

        #region Helper Methods

        private void UpdatePointer()
        {
            if (GamePadStates[0].IsConnected)
            {

                position.X += (GamePadStates[0].ThumbSticks.Left.X * scrollSpeed);
                position.Y -= (GamePadStates[0].ThumbSticks.Left.Y * scrollSpeed);
            }
            else
            {
#if !XBOX360
                position.X = MouseState.X;
                position.Y = MouseState.Y;
#endif
            }
            MathHelper.Clamp(position.X, 0, Game.GraphicsDevice.Viewport.Width);
            MathHelper.Clamp(position.Y, 0, Game.GraphicsDevice.Viewport.Height);
        }

        #endregion
    }
}
