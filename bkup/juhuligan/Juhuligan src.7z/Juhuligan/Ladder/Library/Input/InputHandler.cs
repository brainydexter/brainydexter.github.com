#region FileDescription
//
// This file contains the InputHandler game component for handling keyboard, mouse, and controller input.
// This file also contains two helper classes: ButtonHandler and KeyboardHandler which help test button conditions
//
#endregion

using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;

namespace Library.InputNS
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class InputHandler : Microsoft.Xna.Framework.GameComponent, IInputHandler
    {
        #region Fields

        public enum ControllerButtons       // Buttons on XBOX360 Controller
        {
            A,
            B,
            Back,
            Down,
            Left,
            LeftShoulder,
            LeftStick,
            Right,
            RightShoulder,
            RightStick,
            Start,
            Up,
            X,
            Y
        };

        public enum ControllerTrigger
        {
            LeftTrigger,
            RightTrigger,
        };


        public enum MouseButtons            // Button on mouse
        {
            Left,
            Middle,
            Right
        };

        public enum MouseDirections         // Dirctions of mouse movement
        {
            Down,
            Left,
            Right,
            Up
        };

        public enum MouseWheelDirections
        {
            Forward,
            Back
        };

        private KeyboardState keyboardState;                            // Current keyboard state
        private KeyboardState previousKeyboardState;                    // Previous keyboard state
        private GamePadState[] gamePadStates = new GamePadState[4];     // Current gamepad states
        private GamePadState[] prevGamePadStates = new GamePadState[4]; // Previous gamepad states

#if !XBOX360
        private MouseState mouseState;                                  // Current mouse state
        private MouseState prevMouseState;                              // Previous mouse state
#endif

        #endregion

        #region Properties

        public KeyboardState KeyboardState
        {
            get { return (keyboardState); }
        }

        public GamePadState[] GamePadStates
        {
            get { return (gamePadStates); }
        }

#if !XBOX360
        public MouseState MouseState
        {
            get { return (mouseState); }
        }
#endif

        #endregion

        #region Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="game">Current game</param>
        public InputHandler(Game game)
            : base(game)
        {
            //game.Services.AddService(typeof(IInputHandler), this);
            //game.Components.Add(this);
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // Store current states in previous array
            prevGamePadStates[0] = GamePad.GetState(PlayerIndex.One);
            prevGamePadStates[1] = GamePad.GetState(PlayerIndex.Two);
            prevGamePadStates[2] = GamePad.GetState(PlayerIndex.Three);
            prevGamePadStates[3] = GamePad.GetState(PlayerIndex.Four);

            previousKeyboardState = Keyboard.GetState();

#if!XBOX360
            Game.IsMouseVisible = true;
            prevMouseState = Mouse.GetState();
#endif

            base.Initialize();
        }

        #endregion

        #region Update

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // Store current states in previous
            prevGamePadStates[0] = gamePadStates[0];
            prevGamePadStates[1] = gamePadStates[1];
            prevGamePadStates[2] = gamePadStates[2];
            prevGamePadStates[3] = gamePadStates[3];

            // Set current state to current values
            gamePadStates[0] = GamePad.GetState(PlayerIndex.One);
            gamePadStates[1] = GamePad.GetState(PlayerIndex.Two);
            gamePadStates[2] = GamePad.GetState(PlayerIndex.Three);
            gamePadStates[3] = GamePad.GetState(PlayerIndex.Four);

#if !XBOX360
            prevMouseState = mouseState;
            mouseState = Mouse.GetState();
            
            previousKeyboardState = keyboardState;
            keyboardState = Keyboard.GetState();
#endif

            base.Update(gameTime);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Checks to see if a controler button was pressed since last update
        /// </summary>
        /// <param name="playerIndex">Index of controller being tested</param>
        /// <param name="button">Button being tested</param>
        /// <returns>True if button was just pressed, false otherwise</returns>
        public bool ControllerButtonJustPressed(int playerIndex, ControllerButtons button)
        {
            switch (button)
            {
                case ControllerButtons.A:
                    {
                        return (gamePadStates[playerIndex].Buttons.A == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.A == ButtonState.Released);
                    }
                case ControllerButtons.B:
                    {
                        return (gamePadStates[playerIndex].Buttons.B == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.B == ButtonState.Released);
                    }
                case ControllerButtons.Back:
                    {
                        return (gamePadStates[playerIndex].Buttons.Back == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.Back == ButtonState.Released);
                    }
                case ControllerButtons.Down:
                    {
                        return (gamePadStates[playerIndex].DPad.Down == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].DPad.Down == ButtonState.Released);
                    }
                case ControllerButtons.Left:
                    {
                        return (gamePadStates[playerIndex].DPad.Left == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].DPad.Left == ButtonState.Released);
                    }
                case ControllerButtons.LeftShoulder:
                    {
                        return (gamePadStates[playerIndex].Buttons.LeftShoulder == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.LeftShoulder == ButtonState.Released);
                    }
                case ControllerButtons.LeftStick:
                    {
                        return (gamePadStates[playerIndex].Buttons.LeftStick == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.LeftStick == ButtonState.Released);
                    }
                case ControllerButtons.Right:
                    {
                        return (gamePadStates[playerIndex].DPad.Right == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].DPad.Right == ButtonState.Released);
                    }
                case ControllerButtons.RightShoulder:
                    {
                        return (gamePadStates[playerIndex].Buttons.RightShoulder == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.RightShoulder == ButtonState.Released);
                    }
                case ControllerButtons.RightStick:
                    {
                        return (gamePadStates[playerIndex].Buttons.RightStick == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.RightStick == ButtonState.Released);
                    }
                case ControllerButtons.Start:
                    {
                        return (gamePadStates[playerIndex].Buttons.Start == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.Start == ButtonState.Released);
                    }
                case ControllerButtons.Up:
                    {
                        return (gamePadStates[playerIndex].DPad.Up == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].DPad.Up == ButtonState.Released);
                    }
                case ControllerButtons.X:
                    {
                        return (gamePadStates[playerIndex].Buttons.X == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.X == ButtonState.Released);
                    }
                case ControllerButtons.Y:
                    {
                        return (gamePadStates[playerIndex].Buttons.Y == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.Y == ButtonState.Released);
                    }
                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

        /// <summary>
        /// Checks to see if a controler button was released since last update
        /// </summary>
        /// <param name="playerIndex">Index of controller being tested</param>
        /// <param name="button">Button being tested</param>
        /// <returns>True if button was just released, false otherwise</returns>
        public bool ControllerButtonJustReleased(int playerIndex, ControllerButtons button)
        {
            switch (button)
            {
                case ControllerButtons.A:
                    {
                        return (gamePadStates[playerIndex].Buttons.A == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.A == ButtonState.Pressed);
                    }
                case ControllerButtons.B:
                    {
                        return (gamePadStates[playerIndex].Buttons.B == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.B == ButtonState.Pressed);
                    }
                case ControllerButtons.Back:
                    {
                        return (gamePadStates[playerIndex].Buttons.Back == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.Back == ButtonState.Pressed);
                    }
                case ControllerButtons.Down:
                    {
                        return (gamePadStates[playerIndex].DPad.Down == ButtonState.Released &&
                            prevGamePadStates[playerIndex].DPad.Down == ButtonState.Pressed);
                    }
                case ControllerButtons.Left:
                    {
                        return (gamePadStates[playerIndex].DPad.Left == ButtonState.Released &&
                            prevGamePadStates[playerIndex].DPad.Left == ButtonState.Pressed);
                    }
                case ControllerButtons.LeftShoulder:
                    {
                        return (gamePadStates[playerIndex].Buttons.LeftShoulder == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.LeftShoulder == ButtonState.Pressed);
                    }
                case ControllerButtons.LeftStick:
                    {
                        return (gamePadStates[playerIndex].Buttons.LeftStick == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.LeftStick == ButtonState.Pressed);
                    }
                case ControllerButtons.Right:
                    {
                        return (gamePadStates[playerIndex].DPad.Right == ButtonState.Released &&
                            prevGamePadStates[playerIndex].DPad.Right == ButtonState.Pressed);
                    }
                case ControllerButtons.RightShoulder:
                    {
                        return (gamePadStates[playerIndex].Buttons.RightShoulder == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.RightShoulder == ButtonState.Pressed);
                    }
                case ControllerButtons.RightStick:
                    {
                        return (gamePadStates[playerIndex].Buttons.RightStick == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.RightStick == ButtonState.Pressed);
                    }
                case ControllerButtons.Start:
                    {
                        return (gamePadStates[playerIndex].Buttons.Start == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.Start == ButtonState.Pressed);
                    }
                case ControllerButtons.Up:
                    {
                        return (gamePadStates[playerIndex].DPad.Up == ButtonState.Released &&
                            prevGamePadStates[playerIndex].DPad.Up == ButtonState.Pressed);
                    }
                case ControllerButtons.X:
                    {
                        return (gamePadStates[playerIndex].Buttons.X == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.X == ButtonState.Pressed);
                    }
                case ControllerButtons.Y:
                    {
                        return (gamePadStates[playerIndex].Buttons.Y == ButtonState.Released &&
                            prevGamePadStates[playerIndex].Buttons.Y == ButtonState.Pressed);
                    }
                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

        /// <summary>
        /// Checks to see if a controler button has been held down since last update
        /// </summary>
        /// <param name="playerIndex">Index of controller being tested</param>
        /// <param name="button">Button being tested</param>
        /// <returns>True if button was held down, false otherwise</returns>
        public bool ControllerButtonHeldDown(int playerIndex, ControllerButtons button)
        {
            switch (button)
            {
                case ControllerButtons.A:
                    {
                        return (gamePadStates[playerIndex].Buttons.A == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.A == ButtonState.Pressed);
                    }
                case ControllerButtons.B:
                    {
                        return (gamePadStates[playerIndex].Buttons.B == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.B == ButtonState.Pressed);
                    }
                case ControllerButtons.Back:
                    {
                        return (gamePadStates[playerIndex].Buttons.Back == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.Back == ButtonState.Pressed);
                    }
                case ControllerButtons.Down:
                    {
                        return (gamePadStates[playerIndex].DPad.Down == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].DPad.Down == ButtonState.Pressed);
                    }
                case ControllerButtons.Left:
                    {
                        return (gamePadStates[playerIndex].DPad.Left == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].DPad.Left == ButtonState.Pressed);
                    }
                case ControllerButtons.LeftShoulder:
                    {
                        return (gamePadStates[playerIndex].Buttons.LeftShoulder == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.LeftShoulder == ButtonState.Pressed);
                    }
                case ControllerButtons.LeftStick:
                    {
                        return (gamePadStates[playerIndex].Buttons.LeftStick == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.LeftStick == ButtonState.Pressed);
                    }
                case ControllerButtons.Right:
                    {
                        return (gamePadStates[playerIndex].DPad.Right == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].DPad.Right == ButtonState.Pressed);
                    }
                case ControllerButtons.RightShoulder:
                    {
                        return (gamePadStates[playerIndex].Buttons.RightShoulder == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.RightShoulder == ButtonState.Pressed);
                    }
                case ControllerButtons.RightStick:
                    {
                        return (gamePadStates[playerIndex].Buttons.RightStick == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.RightStick == ButtonState.Pressed);
                    }
                case ControllerButtons.Start:
                    {
                        return (gamePadStates[playerIndex].Buttons.Start == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.Start == ButtonState.Pressed);
                    }
                case ControllerButtons.Up:
                    {
                        return (gamePadStates[playerIndex].DPad.Up == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].DPad.Up == ButtonState.Pressed);
                    }
                case ControllerButtons.X:
                    {
                        return (gamePadStates[playerIndex].Buttons.X == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.X == ButtonState.Pressed);
                    }
                case ControllerButtons.Y:
                    {
                        return (gamePadStates[playerIndex].Buttons.Y == ButtonState.Pressed &&
                            prevGamePadStates[playerIndex].Buttons.Y == ButtonState.Pressed);
                    }
                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

        /// <summary>
        /// Checks to see if a controler trigger was pulled since the last frame
        /// </summary>
        /// <param name="playerIndex">Index of controller being tested</param>
        /// <param name="trigger">Trigger being tested</param>
        /// <returns>True if the trigger was just pulled, false otherwise</returns>
        public bool ControllerTriggerJustPulled(int playerIndex, ControllerTrigger trigger)
        {
            switch (trigger)
            {
                case ControllerTrigger.LeftTrigger:
                    {
                        return (gamePadStates[playerIndex].Triggers.Left != 0 &&
                                prevGamePadStates[playerIndex].Triggers.Left == 0);
                    }

                case ControllerTrigger.RightTrigger:
                    {
                        return (gamePadStates[playerIndex].Triggers.Right != 0 &&
                                prevGamePadStates[playerIndex].Triggers.Right == 0);
                    }

                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

        public float ControllerTriggerDelta(int playerIndex, ControllerTrigger trigger)
        {
            switch (trigger)
            {
                case ControllerTrigger.LeftTrigger:
                    {
                        return (gamePadStates[playerIndex].Triggers.Left -
                                prevGamePadStates[playerIndex].Triggers.Left);
                    }

                case ControllerTrigger.RightTrigger:
                    {
                        return (gamePadStates[playerIndex].Triggers.Right -
                                prevGamePadStates[playerIndex].Triggers.Right);
                    }

                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

        /// <summary>
        /// Checks to see if a controler trigger was released since the last frame
        /// </summary>
        /// <param name="playerIndex">Index of controller being tested</param>
        /// <param name="trigger">Trigger being tested</param>
        /// <returns>True if the trigger was just released, false otherwise</returns>
        public bool ControllerTriggerJustReleased(int playerIndex, ControllerTrigger trigger)
        {
            switch (trigger)
            {
                case ControllerTrigger.LeftTrigger:
                    {
                        return (gamePadStates[playerIndex].Triggers.Left == 0 &&
                                prevGamePadStates[playerIndex].Triggers.Left != 0);
                    }
                case ControllerTrigger.RightTrigger:
                    {
                        return (gamePadStates[playerIndex].Triggers.Right == 0 &&
                                prevGamePadStates[playerIndex].Triggers.Right != 0);
                    }
                default:
                    {
                        throw new ArgumentException();
                    }
            }
        }

        /// <summary>
        /// Tests to see if a key was pressed since last update
        /// </summary>
        /// <param name="key">Key</param>
        /// <returns>True if key was just pressed, false otherwise</returns>
        public bool KeyJustPressed(Keys key)
        {
            return (keyboardState.IsKeyDown(key) && previousKeyboardState.IsKeyUp(key));
        }

        /// <summary>
        /// Tests to see if a key was released since last update
        /// </summary>
        /// <param name="key">Key</param>
        /// <returns>True if key was just released, false otherwise</returns>
        public bool KeyJustReleased(Keys key)
        {
            return (keyboardState.IsKeyUp(key) && previousKeyboardState.IsKeyDown(key));
        }

        /// <summary>
        /// Tests to see if a key has been held down since the last update
        /// </summary>
        /// <param name="key">Key</param>
        /// <returns>True is key was held down, false otherwise</returns>
        public bool KeyHeldDown(Keys key)
        {
            return (keyboardState.IsKeyDown(key) && previousKeyboardState.IsKeyDown(key));
        }

        /// <summary>
        /// Tests to see if a key is currently down
        /// </summary>
        /// <param name="key">Key</param>
        /// <returns>True is key is down, false otherwise</returns>
        public bool IsKeyDown(Keys key)
        {
            return keyboardState.IsKeyDown(key);
        }

#if !XBOX360

        /// <summary>
        /// Check to see if the mouse moved in the specified direction since last update
        /// </summary>
        /// <param name="direction">Direction beign checked</param>
        /// <returns>True if mouse moved in specified direction, false otherwise</returns>
        public bool MouseMoved(MouseDirections direction)
        {
            switch (direction)
            {
                case MouseDirections.Down:
                    {
                        return (mouseState.Y < prevMouseState.Y);
                    }
                case MouseDirections.Left:
                    {
                        return (mouseState.X < prevMouseState.X);
                    }
                case MouseDirections.Right:
                    {
                        return (mouseState.X > prevMouseState.X);
                    }
                case MouseDirections.Up:
                    {
                        return (mouseState.Y > prevMouseState.Y);
                    }
                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

        /// <summary>
        /// Checks to see if a mouse button was pressed since the last update
        /// </summary>
        /// <param name="button">Button checked</param>
        /// <returns>True if button was pressed since last update, false otherwise</returns>
        public bool MouseButtonJustPressed(MouseButtons button)
        {
            switch (button)
            {
                case MouseButtons.Left:
                    {
                        return (mouseState.LeftButton == ButtonState.Pressed &&
                            prevMouseState.LeftButton == ButtonState.Released);
                    }
                case MouseButtons.Middle:
                    {
                        return (mouseState.MiddleButton == ButtonState.Pressed &&
                            prevMouseState.MiddleButton == ButtonState.Released);
                    }
                case MouseButtons.Right:
                    {
                        return (mouseState.RightButton == ButtonState.Pressed &&
                            prevMouseState.RightButton == ButtonState.Released);
                    }
                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

        /// <summary>
        /// Checks to see if a mouse button was released since the last update
        /// </summary>
        /// <param name="button">Button checked</param>
        /// <returns>True if button was released since last update, false otherwise</returns>
        public bool MouseButtonJustReleased(MouseButtons button)
        {
            switch (button)
            {
                case MouseButtons.Left:
                    {
                        return (mouseState.LeftButton == ButtonState.Released &&
                            prevMouseState.LeftButton == ButtonState.Pressed);
                    }
                case MouseButtons.Middle:
                    {
                        return (mouseState.MiddleButton == ButtonState.Released &&
                            prevMouseState.MiddleButton == ButtonState.Pressed);
                    }
                case MouseButtons.Right:
                    {
                        return (mouseState.RightButton == ButtonState.Released &&
                            prevMouseState.RightButton == ButtonState.Pressed);
                    }
                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

        /// <summary>
        /// Checks to see if a mouse button was held down since the last update
        /// </summary>
        /// <param name="button">Button checked</param>
        /// <returns>True if button was held down since last update, false otherwise</returns>
        public bool MouseButtonHeldDown(MouseButtons button)
        {
            switch (button)
            {
                case MouseButtons.Left:
                    {
                        return (mouseState.LeftButton == ButtonState.Pressed &&
                            prevMouseState.LeftButton == ButtonState.Pressed);
                    }
                case MouseButtons.Middle:
                    {
                        return (mouseState.MiddleButton == ButtonState.Pressed &&
                            prevMouseState.MiddleButton == ButtonState.Pressed);
                    }
                case MouseButtons.Right:
                    {
                        return (mouseState.RightButton == ButtonState.Pressed &&
                            prevMouseState.RightButton == ButtonState.Pressed);
                    }
                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

        public bool MouseWheelRolled(MouseWheelDirections wheelDirection)
        {
            switch (wheelDirection)
            {
                case MouseWheelDirections.Forward:
                    {
                        return mouseState.ScrollWheelValue > prevMouseState.ScrollWheelValue;
                    }
                case MouseWheelDirections.Back:
                    {
                        return mouseState.ScrollWheelValue < prevMouseState.ScrollWheelValue;
                    }
                default:
                    {
                        throw (new ArgumentException());
                    }
            }
        }

#endif

        #endregion
    }
}