﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;

namespace Ladder
{
    class Projectile
    {
        public delegate Vector2 Trajectory(Vector2 startPos, Vector2 endPos);

        public static Dictionary<TrajectoryType, Trajectory> projectileDictionary; 
        
        static Projectile()
        {
            projectileDictionary = new Dictionary<TrajectoryType, Trajectory>();

            projectileDictionary.Add(TrajectoryType.Straight, new Trajectory(StraightT));
        }

        public static Vector2 StraightT(Vector2 startPos, Vector2 endPos)
        {
            Vector2 vel = endPos - startPos;

            vel.Normalize();

            vel *= 0.05f;
            return vel;
        }

        public static Vector2 ProcessTrajectory(Projectile.Trajectory trajectoryDelegate, Vector2 v1, Vector2 v2)
        {
            if (trajectoryDelegate != null)
                return trajectoryDelegate(v1, v2);

            return Vector2.Zero;
        }

    }

    enum TrajectoryType
    {
        None,
        Straight,
        LeapFrog,
        Quartere,
        Boomerang
    }
}
