using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Library.SpriteBoard;

namespace Ladder.Resources
{
    abstract class Resource
    {
        #region Fields

        protected int spriteIndex;
        protected Point positionWorld;
        protected Vector2 position;

        protected bool consumed;

        protected bool active;

        protected SpriteSheet spriteSheet;
        #endregion

        #region Properties

        public int SpriteIndex
        {
            get { return spriteIndex; }
        }

        public bool Consumed
        {
            get { return consumed; }
            set { consumed = value; }
        }

        /// <summary>
        /// Resource still exists or exhausted
        /// </summary>
        public bool Active
        {
            get { return active; }
            set { active = value; }
        }

        public Point PositionWorld
        {
            get { return positionWorld; }
            set { positionWorld = value; }
        }

        public abstract Rectangle BoundingBox{get;}

        #endregion

        public Resource(Point posn)
        {
            Consumed = false;

            positionWorld = posn;

            position.X = posn.X * Constants.TileWidth;
            position.Y = posn.Y * Constants.TileHeight;
        }

        /// <summary>
        /// Updates the player depending on the resource.
        /// </summary>
        /// <param name="gameTime">Snapshot of the time</param>
        /// <param name="player">Player whose attribs are changed as per resources</param>
        public abstract void Update(GameTime gameTime, Ladder.PC.IPlayer player);

        public abstract void Action(GameTime gameTime, Ladder.PC.IPlayer player);

        public abstract void Draw(GameTime gameTime, Vector2 drawPosn,int viewPortX);
    }
}
