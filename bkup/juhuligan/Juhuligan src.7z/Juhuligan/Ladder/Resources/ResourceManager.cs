#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

using Library.SpriteSheetNS;
using Library.UtilsNS;

using Ladder.PC;
using Ladder.WorldNS;
#endregion

namespace Ladder.Resources
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class ResourceManager : Microsoft.Xna.Framework.DrawableGameComponent
    {
        #region Fields

        SpriteSheet spriteSheet;

        List<Pickup> pickUpList;
        List<Weapon> weaponList;

        IPlayer player;

        #endregion

        #region Initialization

        public ResourceManager(Game game)
            : base(game)
        {
            // TODO: Construct any child components here     
            spriteSheet = new SpriteSheet(Game.Content, Constants.Resources_Sprite_Path,
                Constants.ResourceSprite_TileWidth, Constants.ResourceSprite_TileHeight,
                Constants.ResourceSprite_TileXCount, Constants.ResourceSprite_TileYCount);

            weaponList = new List<Weapon>();

            pickUpList = new List<Pickup>();
        }

        /// <summary>
        /// Allows the game component to perform any initialization it needs to before starting
        /// to run.  This is where it can query for any required services and load content.
        /// </summary>
        public override void Initialize()
        {
            // TODO: Add your initialization code here
            base.Initialize();

            player = Game.Services.GetService(typeof(IPlayer)) as IPlayer;

            //weaponList.Add(new Weapon(Game, spriteSheet, new Vector2(3, 11)));

            foreach (QueItem item in LevelLoader.GetInstance(Game).ResourceQ)
            {
                switch (item.type)
                {
                    case (int)PickupType.Coin:
                        pickUpList.Add(new Pickup(Game, PickupType.Coin, spriteSheet, new Vector2(item.x, item.y), null));
                        break;

                    case (int)PickupType.Ammo:
                        pickUpList.Add(new Pickup(Game, PickupType.Ammo, spriteSheet, new Vector2(item.x, item.y), null));
                        break;


                    case (int)PickupType.Shield:
                        pickUpList.Add(new Pickup(Game, PickupType.Shield, spriteSheet, new Vector2(item.x, item.y), null));
                        break;

                    case (int)PickupType.MediPack:
                        pickUpList.Add(new Pickup(Game, PickupType.MediPack, spriteSheet, new Vector2(item.x, item.y), null));
                        break;

                    case Constants.WeaponTile:
                        weaponList.Add(new Weapon(Game, spriteSheet, new Vector2(item.x, item.y)));
                        break;
                }
            }

            pickUpList.Add(new Pickup(Game, PickupType.Home, spriteSheet, new Vector2(98, 8), null));

            //weaponList.Add(new Weapon(Game, spriteSheet, new Vector2(4, 11)));
            #region test data
            //pickUpList.Add(new Pickup(Game, PickupType.MediPack, spriteSheet, new Vector2(2, 10),null));
            //pickUpList.Add(new Pickup(Game, PickupType.Ammo, spriteSheet, new Vector2(8, 10),
            //                               new Timer(Game, 5,TimerMode.Exhaust,TimerDirection.Reverse)));
            //pickUpList.Add(new Pickup(Game, PickupType.Shield, spriteSheet, new Vector2(0, 10),null));
            //pickUpList.Add(new Pickup(Game, PickupType.Coin, spriteSheet, new Vector2(1, 11), null));
            //pickUpList.Add(new Pickup(Game, PickupType.Coin, spriteSheet, new Vector2(10, 11), null));
            //pickUpList.Add(new Pickup(Game, PickupType.MediPack, spriteSheet, new Vector2(99, 11), null));
            #endregion

            foreach (Weapon weapon in weaponList)
                weapon.Initialize();

            foreach (Pickup pickUp in pickUpList)
                pickUp.Initialize();

        }

        /// <summary>
        /// This takes care of loading the common spritesheet for all the resources.
        /// </summary>
        public void LoadContent()
        {
            spriteSheet.Load();
        }
        #endregion

        #region Update

        /// <summary>
        /// Updates the Weapons and resources.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            // TODO: Add your update code here
            base.Update(gameTime);

            for(int i = 0; i < weaponList.Count; i++)
            {
                if (weaponList[i].Update(gameTime, player) == UpdateAction.Remove)
                {
                    weaponList.RemoveAt(i);
                }
            }

            for (int i = 0; i < pickUpList.Count; i++)
            {
                if (pickUpList[i].Update(gameTime, player) == UpdateAction.Remove)
                {
                    pickUpList.RemoveAt(i);
                }
            }

            //int playerX = 0;
            //spawnHealth(playerX);
        }

        #endregion

        #region Draw

        public void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);

            foreach (Weapon weapon in weaponList)
                weapon.Draw(gameTime);

            foreach (Pickup pickUp in pickUpList)
                pickUp.Draw(gameTime);
            
        }

        #endregion

        /// <summary>
        /// spawns health as per some rules
        /// </summary>
        /// <param name="playerX"></param>
        private void spawnHealth(int playerX)
        {
            if (player.WorldPosition.X > playerX)
            {
                List<Pickup> pickUpToAddList = new List<Pickup>();
                int totHealth = 0;
                int count = 0;

                foreach (Pickup pickUp in pickUpList)
                {

                    if (
                        Constants.VectorWithin(
                                pickUp.WorldPosition,
                                new Vector2(playerX, 0), new Vector2(Constants.viewPortWidth, Constants.viewPortHeight)))
                    {
                        //if pickupType is health
                        totHealth += (-Constants.HealthPack);
                        count++;
                    }
                }

                if (count < 2 && player.Health < 130) //&& health on playerX + viewportWidth < 30
                {
                    Random random = new Random((int)DateTime.Now.Ticks);

                    pickUpToAddList.Add(
                            new Pickup(Game, PickupType.MediPack, spriteSheet,
                             new Vector2(random.Next(playerX , playerX + Constants.viewPortWidth), 7),
                            new Timer(Game, 5, TimerMode.Exhaust, TimerDirection.Reverse)));
                }


                foreach (Pickup pickUp in pickUpToAddList)
                    pickUpList.Add(pickUp);
            }
        }

        protected override void Dispose(bool disposing)
        {
            pickUpList.Clear();
            weaponList.Clear();

            player = null;
            base.Dispose(disposing);
        }
    }
}