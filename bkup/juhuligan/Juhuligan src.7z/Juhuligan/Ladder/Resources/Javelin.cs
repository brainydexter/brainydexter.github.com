using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Ladder.PC;
using Ladder.GameObjects;
using Ladder.NPC;
using Ladder.GameStates.GameMenu.PlayGameMenu;

namespace Ladder.Resources
{
    class Javelin : Resource
    {
        Vector2 velocity;
        
        List<Ammo> bullets;

        float elapsedTime;

        #region Initialization

        public Javelin(Point posn)
            : base(posn)
        {
            spriteIndex = 1;

            velocity = Vector2.Zero;
            bullets = new List<Ammo>();
            bullets.Add(new Ammo(AmmoType.Bullet, position, null));
            bullets.Add(new Ammo(AmmoType.Bullet, position, null));
            bullets.Add(new Ammo(AmmoType.Bullet, position, null));
            bullets.Add(new Ammo(AmmoType.Bullet, position, null));
            bullets.Add(new Ammo(AmmoType.Bullet, position, null));

        }

        #endregion

        #region Properties

        //todo: Tweak for javelin sprite
        public override Rectangle BoundingBox
        {
            get
            {
                return new Rectangle(
                    (int)position.X + Constants.Javelin_Pixel_XOffset,
                    (int)position.Y + Constants.Javelin_Pixel_YOffset,
                    Constants.Javelin_Width,
                    Constants.Javelin_Height);
            }
        }

        #endregion

        #region Update

        public override void Update(Microsoft.Xna.Framework.GameTime gameTime, IPlayer player)
        {
            if (!Consumed)
            {
                if (BoundingBox.Intersects(player.BoundingBox))
                {
                    Consumed = true;
                    player.addResource(this);
                    spriteSheet = player.Player_SpriteSheet;
                    //remove from the resourceMgr collection
                }
            }
            else
            {
                //positionWorld = player.WorldPosition;
                //ie the javelin is with the player now
                foreach (Ammo bullet in bullets)
                {
                    if (bullet.Active)
                    {
                        bullet.PositionX += bullet.VelocityX;
                        bullet.PositionY += bullet.VelocityY;
                    }
                }
                checkForEnemyHit(player.EnemyPlayer);
            }
        }

        private void checkForEnemyHit(BotPlayer botPlayer)
        {
            Dictionary<Enemy, int> enemyDmg = new Dictionary<Enemy, int>();

            foreach (Ammo bullet in bullets)
            {
                if (bullet.Active)
                {
                    foreach (Enemy enemy in botPlayer.Enemies)
                    {
                        if (enemy.BoundingBox.Intersects(bullet.BoundingBox))
                        {
                            enemyDmg.Add(enemy, bullet.Damage);
                            bullet.Active = false;
                        }
                    }
                }
            }

            foreach (KeyValuePair<Enemy, int> kvp in enemyDmg)
            {
                kvp.Key.updateHealth(kvp.Value);
            }
        }

        #endregion

        public override void Action(GameTime gameTime, IPlayer player)
        {
            Ammo bullet = null;// LoadBullet(gameTime);
            if (bullet != null)
            {
                switch (player.GunDirection)
                {
                    case Direction.Left:
                        bullet.VelocityX = (-2.0f);
                        break;

                    case Direction.Right:
                        bullet.VelocityX = (+2.0f);
                        break;

                    case Direction.Up:
                        bullet.VelocityY = (-2.0f);
                        break;

                    case Direction.Down:
                        bullet.VelocityY = (2.0f);
                        break;
                }
            }
        }

        public override void Draw(GameTime gameTime, Vector2 drawPosition,int viewPortX)
        {
            GamePlayState.SSpriteBatch.Draw(
                spriteSheet.SpriteSheeet,
                new Rectangle(
                            (int)drawPosition.X - (viewPortX * Constants.TileWidth),
                            (int)drawPosition.Y,
                            Constants.ResourceSprite_TileWidth,Constants.ResourceSprite_TileHeight),
                            spriteSheet.getTextureRectangle(Constants.Player_ResourceSprite_Offset + spriteIndex),
                Color.White);

            DrawBullets(drawPosition, viewPortX);
        }

        private void DrawBullets(Vector2 drawPosition,int viewPortX)
        {
            foreach (Ammo bullet in bullets)
            {
                if (bullet.Active)
                {
                    GamePlayState.SSpriteBatch.Draw(
                        spriteSheet.SpriteSheeet,
                        new Rectangle(
                            (int)bullet.PositionX - (viewPortX * Constants.TileWidth),
                            (int)bullet.PositionY,
                            Constants.ResourceSprite_TileWidth, Constants.ResourceSprite_TileHeight),
                        spriteSheet.getTextureRectangle(Constants.Player_ResourceSprite_Offset + 2),
                        Color.White);
                }
            }
        }

        #region Helper Method

        /// <summary>
        /// Selects the inactive bullet from the stocked ammo.
        /// </summary>
        /// <returns>Ammo that is currently inactive</returns>
        private Ammo LoadBullet(GameTime gameTime,Point worldPosn)
        {
            elapsedTime += (float)gameTime.ElapsedGameTime.Milliseconds;

            if (elapsedTime > 0)//Constants.Javelin_ReloadTime)
            {
                elapsedTime = 0.0f;

                foreach (Ammo bullet in bullets)
                    if (!bullet.Active)
                    {
                        bullet.Active = true;
                        bullet.PositionX = worldPosn.X * Constants.TileWidth;
                        bullet.PositionY = worldPosn.Y * Constants.TileHeight;
                        return bullet;
                    }
            }
            return null;
        }

        #endregion
    }
}
