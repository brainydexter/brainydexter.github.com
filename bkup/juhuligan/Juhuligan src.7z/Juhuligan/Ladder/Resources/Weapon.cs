﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;

using Ladder.GameObjects;
using Ladder.PC;

using Library.InputNS;
using Library.SpriteSheetNS;
using Ladder.GameStates.GameMenu.PlayGameMenu;
using Library.AudioNS;


namespace Ladder.Resources
{
    /// <summary>
    /// Constructor defaults tileNumber to 0
    /// Initialize sets the worldPosition to argument posn
    /// </summary>
    class Weapon : GameObject
    {
        #region Fields

        List<Bullet> bulletList;
        float rotation;

        IMouseHandler input;

        #endregion

        #region Properties

        public List<Bullet> BulletList
        {
            get { return bulletList; }
        }

        #endregion

        #region Initialize

        /// <summary>
        /// Initializes the weapon with certain bullets.
        /// Override to change the tileNumber.
        /// </summary>
        public Weapon(Game game, SpriteSheet parentSpriteSheet, Vector2 posn)
            : base(game)
        {
            spriteSheet = parentSpriteSheet;

            tileNumber = 5;

            worldPosition = posn;
            rotation = 0;

            bulletList = new List<Bullet>();
            for (int i = 0; i < 5; i++)
            {
                bulletList.Add(new Bullet(Game, spriteSheet, Constants.Player_Bullet_Tile));
            }
        }

        public override void Initialize()
        {
            base.Initialize();

            input = Game.Services.GetService(typeof(IMouseHandler)) as IMouseHandler;
        }
        #endregion

        #region Update

        /// <summary>
        /// Updates the Weapon.
        /// - if player collides with it, it is removed from the ResourceManager's weaponList
        /// - 2DO: Cool effects
        /// - 2DO: Sound effect
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="player"></param>
        /// <returns></returns>
        public UpdateAction Update(GameTime gameTime, IPlayer player)
        {
            if (BoundingBox.Intersects(player.BoundingBox))
            {
                player.pickUp(this);
                return UpdateAction.Remove;
            }
            return UpdateAction.None;
        }

        /// <summary>
        /// Only called by player
        /// Updates the worldPosition, so that it moves along with the player.
        /// </summary>
        /// <param name="gameTime"></param>
        /// <param name="posn"></param>
        public void Update(GameTime gameTime, Vector2 posn)
        {
            worldPosition = posn;

            Vector2 screenPosn = world.WorldToScreen(worldPosition);

            float x = input.Position.X - screenPosn.X;
            float y = input.Position.Y - screenPosn.Y;

            rotation = (float)Math.Atan2(y, x);

            UpdateInput(gameTime);

            for (int i = 0; i < bulletList.Count; i++)
                if (bulletList[i].UpdateWeaponBullet(gameTime) == UpdateAction.Remove)
                    bulletList.RemoveAt(i);
        }

        private void UpdateInput(GameTime gameTime)
        {
#if!XBOX360
            if (input.MouseButtonJustPressed(InputHandler.MouseButtons.Left))
            {
                FireBullet(); 
            }
#endif
        }

        /// <summary>
        /// Invoked when left mouseButton is pressed.
        /// Selects an inactive bullet and fires it, if available.
        /// </summary>
        private void FireBullet()
        {
           if (0 != bulletList.Count)
            {
                Bullet bullet = null;
                foreach (Bullet blt in bulletList)
                {
                    if (!blt.Active)
                    {
                        bullet = blt;
                        break;
                    }
                }

                if (bullet != null)
                {
                    SoundDJ.GetInstance().PlayCue("fires");
                    bullet.Fire(worldPosition, world.ScreenToWorld(input.Position),TrajectoryType.Straight);
                }
            }
        }

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);
            
            //Drawing the muzzle
            Vector2 screenPosn = world.WorldToScreen(worldPosition);

            GamePlayState.SSpriteBatch.Draw(spriteSheet.SpriteSheeet, 
                new Rectangle( (int)(screenPosn.X + (spriteSheet.TileWidth/2)),(int)screenPosn.Y,spriteSheet.TileWidth,spriteSheet.TileHeight),
                spriteSheet.getTextureRectangle(tileNumber),
                Microsoft.Xna.Framework.Graphics.Color.White, rotation,
                new Vector2(spriteSheet.TileWidth / 2, spriteSheet.TileHeight / 2),
                Microsoft.Xna.Framework.Graphics.SpriteEffects.None, 0f);

            foreach (Bullet bullet in bulletList)
                bullet.Draw(gameTime);
        }

        #endregion

        public void addAmmo(int count)
        {
            for (int i = 0; i < count; i++)
            {
                bulletList.Add(new Bullet(Game, spriteSheet, Constants.Player_Bullet_Tile));
            }
        }
    }
}
