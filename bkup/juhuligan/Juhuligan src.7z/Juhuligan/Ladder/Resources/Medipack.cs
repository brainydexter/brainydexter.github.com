using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Xna.Framework;

using Ladder.PC;

namespace Ladder.Resources
{
    class Medipack : Resource
    {
        #region Initialization

        public Medipack(Point posn)
            : base(posn)
        {
            spriteIndex = 2;
        }

        #endregion

        #region Properties

        public override Microsoft.Xna.Framework.Rectangle BoundingBox
        {
            get
            {
                return new Rectangle(
                    positionWorld.X * Constants.TileWidth,
                    positionWorld.Y * Constants.TileHeight,
                    Constants.TileWidth,
                    Constants.TileHeight);
            }
        }

        #endregion

        #region Update

        public override void Update(Microsoft.Xna.Framework.GameTime gameTime, IPlayer player)
        {
            if (!Consumed)
            {
                if (BoundingBox.Intersects(player.BoundingBox))
                {
                    Consumed = true;
                    //player.addResource(this);
                    player.UpdateHealth(Constants.HealthPack);
                }
            }
        }

        #endregion

        public override void Action(GameTime gameTime, IPlayer player)
        {
            //player.Shield = true;
        }

        public override void Draw(GameTime gameTime, Vector2 drawPosn, int viewPortX)
        {
            
        }
    }
}
