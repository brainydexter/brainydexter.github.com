﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;

using Ladder.GameObjects;
using Ladder.PC;

using Library.SpriteSheetNS;
using Library.UtilsNS;
using Ladder.GameStates.GameMenu.PlayGameMenu;
using Library.AudioNS;

namespace Ladder.Resources
{
    class Pickup : GameObject
    {
        PickupType powerupType;
        bool consumed;

        ITimer timer;

        public Pickup(Game game,PickupType powerup, SpriteSheet parentSpriteSheet, Vector2 posn, ITimer time)
            : base(game)
        {
            spriteSheet = parentSpriteSheet;

            worldPosition = posn;

            powerupType = powerup;
            consumed = false;

            timer = time;
        }

        public override void Initialize()
        {
            switch (powerupType)
            {
                case PickupType.Ammo:
                    tileNumber = 3;
                    break;

                case PickupType.MediPack:
                    tileNumber = 4;
                    break;

                case PickupType.Shield:
                    tileNumber = 0;
                    break;

                case PickupType.Coin:
                    tileNumber = 1;
                    break;

                case PickupType.Home:
                    tileNumber = 6;
                    break;
            }
        }

        public UpdateAction Update(GameTime gameTime, IPlayer player)
        {
            if (null != timer)
            {
                if(false == timer.Alive)
                    return UpdateAction.Remove;

                timer.Update(gameTime);
            }

            if (BoundingBox.Intersects(player.BoundingBox))
            {
                switch (powerupType)
                {
                    case PickupType.MediPack:
                        // sound => Uh..that feels good
                        SoundDJ.GetInstance().PlayCue("health");
                        player.UpdateHealth(Constants.HealthPack);

                        break;

                    case PickupType.Shield:
                        SoundDJ.GetInstance().PlayCue("armor");
                        player.Shield = true;
                        break;

                    case PickupType.Ammo:
                        player.UpdateAmmo(Constants.AmmoPack);
                        break;

                    case PickupType.Coin:
                        SoundDJ.GetInstance().PlayCue("coin");
                        player.UpdateCoin(1);
                        break;

                    case PickupType.Home:
                        SoundDJ.GetInstance().PlayCue("win");
                        player.Victory = VictoryState.Victorious;
                        break;

                }
                consumed = true;

                return UpdateAction.Remove;
            }
            return UpdateAction.None;
        }

        public override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);

            if (null != timer && false != timer.Alive)
            {
                Vector2 screenPosn = world.WorldToScreen(worldPosition);

                timer.Draw(gameTime, screenPosn, GamePlayState.SSpriteBatch);
            }
        }
    }
}
