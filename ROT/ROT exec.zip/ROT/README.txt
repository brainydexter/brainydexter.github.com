The game should run just fine on a Windows Machine.

How to run:
- Double click "ROT.exe" to play the game

If in case the game does not run for you or have any feedback for me, please email me @ fly2priyank AT gmail.com. It would help me if you could provide a small description of what error message it burped at you.

Thank you and have fun!

/Priyank Jain

Compiled @ April 4, 2010 3:43 AM